import GlobalTypes from "./GlobalTypes";
import { postDataAPI } from "../../utils/API";
import axios from "axios";
import { getDataAPI, putDataAPI, deleteDataAPI } from "../../utils/API";

export const ICO_TYPES = {
	LOADING: "LOADING",
	CREATE_ICO: "CREATE_ICO",
	GET_ICO: "GET_ICO",
	ID : "ID"
};

export const creatICO =
	(data, images, abi, text) =>
	async (dispatch) => {
		data.description = text;
		try {
			
			dispatch({ type: GlobalTypes.NOTIFY, payload: { loading: true } });
			if (!images) {
				return dispatch({
					type: GlobalTypes.NOTIFY,
					payload: { error: "please upload logo" },
				});
			}
			
			var abiName = ''
			if(abi){
				abiName = 'abi';
			}
			
			var formData = new FormData();
			formData.append("file", images);
			formData.append("abi", abi)
			formData.append("abiName", abiName)
			
			const resp = await axios.post("/api/upload", formData, {
				headers: { "content-type": "multipart/form-data" },
			});
			const res = await postDataAPI("create_upcPool", {
				...data,
				images: resp.data.url,
				abi_name : abi.name
			});
			
			dispatch({
				type: ICO_TYPES.ID,
				payload: {
					id : res.data.id
				},
			});
			
			dispatch({ type: GlobalTypes.NOTIFY, payload: { loading: false } });
			
			dispatch({
				type: GlobalTypes.NOTIFY,
				payload: {
					success: "pool created successfully",
				
				},
			});
			dispatch({
				type: ICO_TYPES.ID,
				payload: {
					id : ''
				},
			});
		} catch (err) {
			dispatch({
				type: GlobalTypes.NOTIFY,
				payload: {
					error: err.response.data.msg,
				},
			});
		}
	};

export const getico = (page) => async (dispatch) => {
	try {
		dispatch({ type: GlobalTypes.NOTIFY, payload: { loading: true } });
		const res = await getDataAPI("get_upcPool", page);
		
		dispatch({
			type: ICO_TYPES.GET_ICO,
			payload: {
				pool: res.data.pool,
				upcpool: res.data.upcPool,
				featured: res.data.featured,
				paginatedFeatured_pool: res.data.paginatedFeatured_pool,
				totalfeaturedPage: res.data.totalfeaturedPage,
				paginatedUpcomming_pool: res.data.paginatedUpcomming_pool,
				totalUpcommingPage: res.data.totalUpcommingPage,
				completed_Pool: res.data.completed_Pool,
			},
		});

		dispatch({ type: GlobalTypes.NOTIFY, payload: { loading: false } });
	} catch (err) {
		dispatch({
			type: GlobalTypes.NOTIFY,
			payload: { error: err.response.data.msg },
		});
	}
};

export const updateico =
	(
		data,
		id,
		image,
		oldimage,
		abi,
		abi_name,
		text
	) =>
	
	async (dispatch) => {
		data.description = text;
		try {
			
			dispatch({ type: GlobalTypes.NOTIFY, payload: { loading: true } });
			if (image) {
				var IMG = "x";
			} else {
				IMG = "y";
			}

			if(abi){
				var abiName = id + abi.name;
				var ABI = "x";
			} else {
				abiName = abi_name;
				ABI = "y";
			}

			var formData = new FormData();
			formData.append("file", image);
			formData.append("imgname", IMG);

			formData.append("abi", abi)
			formData.append("abiname", ABI)	

			formData.append("id", id);
			//upload image
			if(image){
				const res = await axios.post("/api/uploadtobucket", formData, {
					headers: { "content-type": "multipart/form-data" },
				});
	
				await putDataAPI("update_upcPool", {
					...data,
					id: id,
					images: res.data.url,
					abi_name : abiName,		
				});
			}else{
				await putDataAPI("update_upcPool", {
					...data,
					id: id,
					abi_name : abiName,		
				});
			}
			
			
			dispatch({ type: GlobalTypes.NOTIFY, payload: { loading: false } });
			dispatch({
				type: GlobalTypes.NOTIFY,
				payload: {
					success: "updated successfully",
				},
			});
		} catch (err) {
			dispatch({
				type: GlobalTypes.NOTIFY,
				payload: { error: err.response.data.msg },
			});
		}
	};

	export const deleteico = (id) => async (dispatch) => {
		try {
			console.log(id, 'delete ico')
			dispatch({ type: GlobalTypes.NOTIFY, payload: { loading: true } });
			const res = await deleteDataAPI("delete_upcPool", id);
	
			dispatch({ type: GlobalTypes.NOTIFY, payload: { loading: false } });
			dispatch({
				type: GlobalTypes.NOTIFY,
				payload: {
					success: res.data.msg,
				},
			});
		} catch (err) {
			dispatch({
				type: GlobalTypes.NOTIFY,
				payload: { error: err.response.data.msg },
			});
		}
	};
	

