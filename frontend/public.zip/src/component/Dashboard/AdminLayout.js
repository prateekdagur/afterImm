import React, { useEffect } from "react";
import { Route, Switch } from "react-router-dom";
import $ from "jquery";
import "./AdminLayout.css";
import AdminHeader from "./AdminHeader";
import CreateICO from "./CreateICO";
import DeployNewICO from "./DeployNewICO";
import TransferOwnership from "./TransferOwnership";
import UpdateTier from "./UpdateTier";
import AdminICO from "./AdminICO";
import AddUserInWhiteList from "./AddUserInWhiteList";
import ReadWhiteList from "./ReadWhiteList";
import ListWhitelist from "./ListWhitelist"
import SearchPool from "./SearchPool"
import ClaimTokenLIsting from "./ClaimTokenLIsting"
import Sidebar from "./Sidebar";

//admin layout component
const AdminLayout = () => {
  useEffect(() => {
    $(document).ready(function () {
      $(".list-tab").click(function () {
        $(".upcoming-list").addClass("upcoming-all");
        $(".upcoming-list").removeClass("upcoming-list");
      });

      $(".list-all").click(function () {
        $(".upcoming-all").addClass("upcoming-list");
        $(".upcoming-all").removeClass("upcoming-all");
      });

      $(".list-tab").click(function () {
        $(".list-all").removeClass("active");
        $(".list-tab").addClass("active");
      });

      $(".list-all").click(function () {
        $(".list-tab").removeClass("active");
        $(".list-all").addClass("active");
      });
    });
  });

  return (
    <div className="dashboard">
      <section className="main-section">
        <Sidebar />
        <div className="right-panal">
          <AdminHeader />

          <Switch>
            <Route exact path="/admin/upcommingpool">

              <AdminICO />
            </Route>
            <Route exact path="/admin/completedpool">
              <AdminICO />
            </Route>
            <Route exact path="/admin/featuredpool">
              <AdminICO />
            </Route>
            <Route exact path="/admin/createico">
              <CreateICO />
            </Route>
            <Route exact path="/admin/deploynewico">
              <DeployNewICO />
            </Route>
            <Route exact path="/admin/transferownership/:id">
              <TransferOwnership />
            </Route>
            <Route exact path="/admin/updatetier/:address">
              <UpdateTier />
            </Route>
            <Route exact path="/admin/editico/:id">
              <CreateICO />
            </Route>
            <Route exact path="/admin/adduserinwhitelist/:id">
              <AddUserInWhiteList />
            </Route>
            <Route exact path="/admin/readwhitelist/:address">
              <ReadWhiteList />
            </Route>
            <Route exact path="/admin/listwhitelist/:name/:id">
              <ListWhitelist />
            </Route>
            <Route exact path="/admin/searchpool/:id">
              <SearchPool />
            </Route>
            <Route exact path="/admin/claimtokenlisting/:address">
              <ClaimTokenLIsting />
            </Route>
          </Switch>
        </div>
      </section>
    </div>
  );
};

export default AdminLayout;
