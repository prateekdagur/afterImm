import React from "react";
import "./Staking.css";
import Header from "./Header";
import Footer from "../Home/footer";

const Staking = () => {

	return (
		<div>
            <Header />
			<h2 style={{color:"white"}}> staking</h2>
            
            <h2 style={{color:"white"}}> farming</h2>
            <Footer />
		</div>
	);
};

export default Staking;
