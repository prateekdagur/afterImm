import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { useParams, Link } from "react-router-dom";
import { addwhitelist1, addwhitelist2, addwhitelist3, addwhitelist4, addwhitelist5, addwhitelist6, addwhitelist7, addwhitelist8, addwhitelist9 } from "../../redux/actions/whitelistAction"

//add white list component.
const AddUserInWhiteList = () => {
  const dispatch = useDispatch();

  const [whl1, setWhl1] = useState();
  const [whl2, setWhl2] = useState();
  const [whl3, setWhl3] = useState();
  const [whl4, setWhl4] = useState();
  const [whl5, setWhl5] = useState();
  const [whl6, setWhl6] = useState();
  const [whl7, setWhl7] = useState();
  const [whl8, setWhl8] = useState();
  const [whl9, setWhl9] = useState();



  const id = useParams().id;
  const SubmitWhitelist1 = () => {
    dispatch(addwhitelist1(whl1, id))
  };

  const SubmitWhitelist2 = () => {
    dispatch(addwhitelist2(whl2, id))
  };

  const SubmitWhitelist3 = () => {
    dispatch(addwhitelist3(whl3, id))
  };

  const SubmitWhitelist4 = () => {
    dispatch(addwhitelist4(whl4, id))
  };

  const SubmitWhitelist5 = () => {
    dispatch(addwhitelist5(whl5, id))
  };

  const SubmitWhitelist6 = () => {
    dispatch(addwhitelist6(whl6, id))
  };

  const SubmitWhitelist7 = () => {
    dispatch(addwhitelist7(whl7, id))
  };

  const SubmitWhitelist8 = () => {
    dispatch(addwhitelist8(whl8, id))
  };

  const SubmitWhitelist9 = () => {
    dispatch(addwhitelist9(whl9, id))
  };


  return (
    <div>
      <div className="right-panel-main">
        <h2>Add User In White List</h2>
        <div className="rightpanel-form">
          <div className="form-inner form-width">
            <div className="form-group">
              <label>Add White List One</label>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <input
                  type="email"
                  className="input-form"
                  placeholder="Enter the address"
                  required
                  onChange={(e) => setWhl1(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => SubmitWhitelist1()}
                  className="bttn"
                >
                  SUBMIT
                </button>
                <Link to={`/admin/listwhitelist/one/${id}`} className="whitelistlink">
                  whitelist One
                </Link>
              </div>
            </div>
          </div>
          <div className="form-inner form-width">
            <div className="form-group">
              <label>Add White List Two</label>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <input
                  type="email"
                  className="input-form"
                  placeholder="Enter the address"
                  required
                  onChange={(e) => setWhl2(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => SubmitWhitelist2()}
                  className="bttn"
                >
                  SUBMIT
                </button>
                <Link to={`/admin/listwhitelist/two/${id}`} className="whitelistlink">
                  whitelist Two
                </Link>
              </div>
            </div>
          </div>
          <div className="form-inner form-width">
            <div className="form-group">
              <label>Add White List Three</label>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <input
                  type="email"
                  className="input-form"
                  placeholder="Enter the address"
                  required
                  onChange={(e) => setWhl3(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => SubmitWhitelist3()}
                  className="bttn"
                >
                  SUBMIT
                </button>
                <Link to={`/admin/listwhitelist/three/${id}`} className="whitelistlink">
                  whitelist Three
                </Link>
              </div>
            </div>
          </div>
          <div className="form-inner form-width">
            <div className="form-group">
              <label>Add White List Four</label>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <input
                  type="email"
                  className="input-form"
                  placeholder="Enter the address"
                  required
                  onChange={(e) => setWhl4(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => SubmitWhitelist4()}
                  className="bttn"
                >
                  SUBMIT
                </button>
                <Link to={`/admin/listwhitelist/four/${id}`} className="whitelistlink">
                  whitelist Four
                </Link>
              </div>
            </div>
          </div>
          <div className="form-inner form-width">
            <div className="form-group">
              <label>Add White List Five</label>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <input
                  type="email"
                  className="input-form"
                  placeholder="Enter the address"
                  required
                  onChange={(e) => setWhl5(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => SubmitWhitelist5()}
                  className="bttn"
                >
                  SUBMIT
                </button>
                <Link to={`/admin/listwhitelist/five/${id}`} className="whitelistlink">
                  whitelist Five
                </Link>
              </div>
            </div>
          </div>
          <div className="form-inner form-width">
            <div className="form-group">
              <label>Add White List Six</label>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <input
                  type="email"
                  className="input-form"
                  placeholder="Enter the address"
                  required
                  onChange={(e) => setWhl6(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => SubmitWhitelist6()}
                  className="bttn"
                >
                  SUBMIT
                </button>
                <Link to={`/admin/listwhitelist/six/${id}`} className="whitelistlink">
                  whitelist Six
                </Link>
              </div>
            </div>
          </div>
          <div className="form-inner form-width">
            <div className="form-group">
              <label>Add White List Seven</label>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <input
                  type="email"
                  className="input-form"
                  placeholder="Enter the address"
                  required
                  onChange={(e) => setWhl7(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => SubmitWhitelist7()}
                  className="bttn"
                >
                  SUBMIT
                </button>
                <Link to={`/admin/listwhitelist/seven/${id}`} className="whitelistlink">
                  whitelist Seven
                </Link>
              </div>
            </div>
          </div>
          <div className="form-inner form-width">
            <div className="form-group">
              <label>Add White List Eight</label>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <input
                  type="email"
                  className="input-form"
                  placeholder="Enter the address"
                  required
                  onChange={(e) => setWhl8(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => SubmitWhitelist8()}
                  className="bttn"
                >
                  SUBMIT
                </button>
                <Link to={`/admin/listwhitelist/eight/${id}`} className="whitelistlink">
                  whitelist Eight
                </Link>
              </div>
            </div>
          </div>
          <div className="form-inner form-width">
            <div className="form-group">
              <label>Add White List Nine</label>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <input
                  type="email"
                  className="input-form"
                  placeholder="Enter the address"
                  required
                  onChange={(e) => setWhl9(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => SubmitWhitelist9()}
                  className="bttn"
                >
                  SUBMIT
                </button>
                <Link to={`/admin/listwhitelist/nine/${id}`} className="whitelistlink">
                  whitelist Nine
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddUserInWhiteList;
