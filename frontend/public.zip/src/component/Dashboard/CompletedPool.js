import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { getico, deleteico } from "../../redux/actions/icoAction";
import { getstoreClaim, getsendClaimToken } from "../../redux/actions/claimTokenAction";
import Modal from "@material-ui/core/Modal";

//completed pool component.
const CompletedPool = () => {
  const { ico } = useSelector((state) => state);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getico());
  }, [dispatch]);

  const clickClaimStore = (addr) => {
    dispatch(getstoreClaim(addr));

  };
  const clickSendToken = (addr) => {
    dispatch(getsendClaimToken(addr))
  }

  const downloadcsv = (name) => {
    const link = document.createElement('a');
    link.href = `/exportcsv/${name}-allocation.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  var completed_Pool = 0;
  if (ico.completed_Pool && ico.completed_Pool.length) {
    completed_Pool = 1;
  }
  const [open, setOpen] = useState(false);
  const [Id, setId] = useState('')
  const handleOpen = (id) => {
    setId(id)
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  const deletePool = () => {
    dispatch(deleteico(Id))
    setOpen(false)
    window.location.reload()
  }
  const body = (
    <div className="paper">
      <a className="cancel" href="#cancel" onClick={() => handleClose()} >
        Cancel
      </a>
      <a className="coming-soon" href="#confirm" onClick={deletePool}>
        Confirm
      </a>
    </div>
  );
  return (
    <div>
      <div className="upcoming-list">
        {ico.completed_Pool
          ? ico.completed_Pool.map((pool) => (
            <div key={pool._id} className="inner-box">
              <div className="list-boxes">
                <div className="media">
                  <div className="client-name">
                    <div className="client-img">
                      <img
                        src={pool.images}
                        alt=""
                      />
                    </div>
                    <div className="client-info">
                      <h5>{pool.title}</h5>
                      <h6>{pool.address.slice(0, 5)}...{pool.address.slice(37, 42)}</h6>
                    </div>
                  </div>
                  <div className="update__delete">
                    <Link className="fa fa-trash" onClick={() => handleOpen(pool._id)} ></Link>
                    <Link
                      to={`/admin/editico/${pool._id}`}
                      className="fa fa-pencil-square-o"
                    ></Link>
                  </div>

                </div>
                <div to="#c" className="radio">Ratio per 1 BNB</div>
                <div className="na">
                  {pool.up_pool_raise}
                  <span> {pool.symbol}</span>
                </div>
                <div className="border"></div>
                <div className="percentage">
                  <span className="total">{pool.total_supply ? (pool.distribute_token / pool.total_supply).toFixed(4) * 100 : ""}%</span>
                  <span className="sfund">{pool.distribute_token}/{pool.total_supply} {pool.symbol}</span>
                </div>
              </div>
              <div className="text-center">
                {
                  pool.address ? <Link to={`/admin/adduserinwhitelist/${pool._id}`} className="detail">
                    Add User in White List
                  </Link> : ""
                }
                {/* {pool.address ? 
                <Link to={`/admin/updatetier/${pool.address}`} className="coming-soon">
                Update Tiers Value
                </Link>
                : ""} */}

                {/* {pool.address ? 
                 <Link to={`/admin/readwhitelist/${pool.address}`} className="coming-soon">
                 Read White List
                 </Link>
                 : ""} */}

                {pool.address ?
                  <a href="#prepare-token" onClick={() => clickClaimStore(pool.address)} className="coming-soon">
                    Prepare Claim
                  </a>
                  : ""}

                {pool.address ?
                  <a href="#distribute-token" onClick={() => clickSendToken(pool.address)} className="coming-soon">
                    Distribute Token
                  </a>
                  : ""}
                {pool.address ?
                  <a href="#download-csv" onClick={() => downloadcsv(pool.title)} className="coming-soon">
                    download-allocation
                  </a>
                  : ""}


              </div>
            </div>
          ))
          : ""}
      </div>
      {
        ico.completed_Pool ? "" : <h2 style={{ color: "white", display: "flex", alignItems: "center", justifyContent: "center" }}>No records found</h2>
      }
      <div>
        {/* <a href={`/exportcsv/${title}.csv`} download={`${title}.csv`} id='downloadallocation'> </a> */}
      </div>
      {completed_Pool ? "" : <h2
        style={{
          color: "white",
          width: "100%",
          height: "80vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        No records found
      </h2>}
      <div>
        <Modal
          open={open}
          onClose={handleClose}
          aria-labelledby="simple-modal-title"
          aria-describedby="simple-modal-description">
          {body}
        </Modal>
      </div>
    </div>

  );
};

export default CompletedPool;

