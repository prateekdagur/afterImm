import { BrowserRouter as Router, Route } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { refreshToken } from "./redux/actions/authAction";
import { useEffect } from "react";
import "./App.css";
import Home from "./component/Home/Home";
import PoolDetail from "./component/PoolDetail/PoolDetail";
import Login from "./component/Auth/Login";
import Register from "./component/Auth/Register";
import AdminLayout from "./component/Dashboard/AdminLayout";
import NotFound from "./component/Auth/NotFound";
import Docs from "./component/PoolDetail/Docs";
import Notify from "./component/Auth/Notify";
import Staking from "./component/Home/Staking";
//import Toast from "./component/Auth/Toast"
//redux
function App() {
	const { auth } = useSelector((state) => state);
	const dispatch = useDispatch();

	useEffect(() => {
		dispatch(refreshToken());
	}, [dispatch]);

	return (
		<Router>
			
			<div className="App">
				{/* routes */}
				
				<Notify />
				<Route path="/" exact component={Home} />
				<Route path="/pool_detail/:name/:id" exact component={PoolDetail} />
				<Route path="/admin/login" exact component={Login} />
				<Route path="/register" exact component={Register} />
				<Route path="/docs/:name/:dir" exact component={Docs} />
				<Route path="/staking" exact component={Staking} />

				<Route
					path="/admin/upcommingpool"
					exact
					component={auth.token && auth.role ? AdminLayout : Home}
				/>
				<Route
					path="/admin/deploynewico"
					exact
					component={auth.token && auth.role ? AdminLayout : Home}
				/>
				<Route
					path="/admin/transferownership/:id"
					exact
					component={auth.token && auth.role ? AdminLayout : Home}
				/>
				<Route
					path="/admin/updatetier/:address"
					exact
					component={auth.token && auth.role ? AdminLayout : Home}
				/>
				<Route
					path="/admin/createico"
					exact
					component={auth.token && auth.role ? AdminLayout : Home}
				/>
				<Route
					path="/admin/completedpool"
					exact
					component={auth.token && auth.role ? AdminLayout : Home}
				/>
				<Route
					path="/admin/featuredpool"
					exact
					component={auth.token && auth.role ? AdminLayout : Home}
				/>
				<Route
					path="/admin/editico/:id"
					exact
					component={auth.token && auth.role ? AdminLayout : NotFound}
				/>
				<Route
					path="/admin/adduserinwhitelist/:id"
					exact
					component={auth.token && auth.role ? AdminLayout : NotFound}
				/>
				<Route
					path="/admin/readwhitelist/:address"
					exact
					component={auth.token && auth.role ? AdminLayout : NotFound}
				/>
				<Route
					path="/admin/listwhitelist/:name/:id"
					exact
					component={auth.token && auth.role ? AdminLayout : NotFound}
				/>
				<Route
					path="/admin/searchpool/:id"
					exact
					component={auth.token && auth.role ? AdminLayout : NotFound}
				/>
				<Route
					path="/admin/claimtokenlisting/:address"
					exact
					component={auth.token && auth.role ? AdminLayout : NotFound}
				/>
			</div>
		</Router>
	);
}

export default App;
