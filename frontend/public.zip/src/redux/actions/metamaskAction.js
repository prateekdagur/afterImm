import GlobalTypes from "./GlobalTypes";
import Web3 from "web3";
import Web3Modal from "web3modal";
import WalletConnectProvider from "@walletconnect/web3-provider";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

toast.configure();
export const METAMASK_TYPES = {
	LOADING: "LOADING",
	CONNECT: "CONNECT",
};
let web3 = new Web3(
	new Web3.providers.HttpProvider(
		"https://bsc-dataseed.binance.org/"
		// "https://data-seed-prebsc-1-s1.binance.org:8545/"
	)
);;

const providerOptions = {
	walletconnect: {
		package: WalletConnectProvider,
		options: {
			rpc: {
				56: 'https://bsc-dataseed.binance.org/'
				// 0x61: "https://data-seed-prebsc-1-s1.binance.org:8545/", // BSC Testnet chainId - 97
			},
			chainId: 56, // BSC MainNet
			network: "binance",
		},
	},
};

// const metamaskConnectInit = () => {
// 	// Check if Web3 has been injected by the browser (Mist/MetaMask).
// 	return new Promise((resolve, reject) => {
// 		if (typeof window.web3 !== "undefined") {
// 			// Use Mist/MetaMask's provider.
// 			web3 = new Web3(window.web3.currentProvider);
// 			localStorage.setItem("modalProvider", 0);
// 			resolve(true);
// 		} else {
// 			// Handle the case where the user doesn't have web3. Probably
// 			// show them a message telling them to install Metamask in
// 			// order to use the app.
// 			web3 = new Web3(
// 				new Web3.providers.HttpProvider(
// 					// "https://bsc-dataseed.binance.org/"
// 					"https://data-seed-prebsc-1-s1.binance.org:8545/"
// 				)
// 			);
// 			reject(false);
// 		}
// 	});
// };

export const connectWallet = () => async (dispatch) => {
	try {
		const web3Modal = new Web3Modal({
			cacheProvider: true,
			providerOptions,
		});
		//connect
        console.log("new called");
		const provider = await web3Modal.connect();
		console.log("provider oected",provider)
		window.provider = provider;
		web3 = new Web3(provider);
		localStorage.setItem("modalProvider", 1);
		//get address
		const accounts = await web3.eth.getAccounts();
		const address = accounts[0];
		window.addressselected = accounts[0];
		window.checkconnect = address;
		// //get network id

		const chainid = await web3.eth.net.getId();
		if (
			chainid !== "0x38" &&
			chainid !== 56 &&
			chainid !== "0x61" &&
			chainid !== 97
		) {
			return toast.info("Connect your wallet to Binance Smart Chain!", {
				position: toast.POSITION.TOP_CENTER,
			});
		}

		if (chainid === 56 || chainid === "0x38" || chainid === "0x61" || chainid === 97) {
			localStorage.setItem("address", address);
			provider.on("disconnect", () => {
				dispatch({
					type: METAMASK_TYPES.CONNECT,
					payload: {
						provider: false,
						active: true,
						design: false,
					},
				});
			});
			provider.on("accountsChanged", (accounts) => {
				const address = accounts[0];
				if (accounts.length > 0) {
					dispatch({
						type: METAMASK_TYPES.CONNECT,
						payload: {
							address: address,
							provider: provider,
							active: false,
							design: true,
							showAddress: address.slice(0, 4) + "..." + address.slice(38, 42),
						},
					});

					localStorage.setItem("address", address);
				} else {
					dispatch({
						type: METAMASK_TYPES.CONNECT,
						payload: {
							address: "",
							active: true,
							design: false,
							showAddress: "",
						},
					});
					localStorage.removeItem("address", address);
				}
			});

			provider.on("chainChanged", (chainId) => {
				if (chainId !== 56 || chainid === "0x61" || chainid === 97) {
					web3Modal.clearCachedProvider();
					dispatch({
						type: METAMASK_TYPES.CONNECT,
						payload: {
							address: "",
							active: true,
							design: false,
							showAddress: "",
						},
					});
					toast.info("Please switch to Binance Smart Chain", {
						position: toast.POSITION.TOP_CENTER,
					});
				}
				if (chainId === 56 || chainid === "0x61" || chainid === 97) {
					dispatch({
						type: METAMASK_TYPES.CONNECT,
						payload: {
							address: address,
							provider: provider,
							active: false,
							design: true,
							showAddress: address.slice(0, 4) + "..." + address.slice(38, 42),
						},
					});
				}
			});
			if (chainid === 56 || chainid === "0x61" || chainid === 97) {
				dispatch({
					type: METAMASK_TYPES.CONNECT,
					payload: {
						address: address,
						provider: provider,
						active: false,
						design: true,
						showAddress: address.slice(0, 4) + "..." + address.slice(38, 42),
					},
				});
			} else {
				localStorage.removeItem("WEB3_CONNECT_CACHED_PROVIDER");
				toast.info("Please switch to Binance Smart Chain", {
					position: toast.POSITION.TOP_CENTER,
				});
			}
		}
	} catch (err) {
		if(err && err.response && err.response.data){
			dispatch({
				type: GlobalTypes.NOTIFY,
				payload: {
				  error: err.response.data.msg,
				},
			  });
		}
	}
};

export const checkWalletConnection = () => async (dispatch) => {
	try {
		var prevAddress = localStorage.getItem("address");

		if (prevAddress && prevAddress !== "undefined") {
			const web3Modal = new Web3Modal({
				cacheProvider: true,
				providerOptions,
			});

			const provider = await web3Modal.connect();
			window.provider = provider;
			web3 = new Web3(provider);
			const accounts = await web3.eth.getAccounts();
		   var address = accounts[0];
		   window.addressselected = accounts[0];
		   window.checkconnect = address;
			// const provider = Web3.givenProvider;
			const chainid = provider.chainId;
		  console.log(address);
			if (
				chainid === "0x38" ||
				chainid === 56 ||
				chainid === "0x61" ||
				chainid === 97
			) {
				dispatch({
					type: METAMASK_TYPES.CONNECT,
					payload: {
						address: address,
						active: false,
						design: true,
						showAddress: address.slice(0, 4) + "..." + address.slice(38, 42),
					},
				});
			}
			console.log("provider", address);
			if (address !== "") {
                localStorage.setItem("modalProvider", 1);
				//address = (provider.chainId === "0x38") ? provider.selectedAddress : (provider?.accounts[0]);

				localStorage.setItem("address", address);

				provider.on("connect", (chainid) => {
					console.log("connected", address);
					if (
						chainid !== "0x38" ||
						chainid !== 56 ||
						chainid !== "0x61" ||
						chainid !== 97
					) {
						dispatch({
							type: METAMASK_TYPES.CONNECT,
							payload: {
								active: true,
								design: false,
								showAddress: "",
							},
						});
					}else dispatch({
						type: METAMASK_TYPES.CONNECT,
						payload: {
							address: address,
							active: false,
							design: true,
							showAddress: address.slice(0, 4) + "..." + address.slice(38, 42),
						},
					});
				});
				provider.on("disconnect", () => {
					dispatch({
						type: METAMASK_TYPES.CONNECT,
						payload: {
							active: true,
							design: false,
							showAddress: "",
						},
					});
				});
				provider.on("accountsChanged", (accounts) => {
					if (
						provider.chainId !== "0x38" ||
						provider.chainId !== 56 ||
						provider.chainid !== "0x61" ||
						provider.chainid !== 97
					) {
						dispatch({
							type: METAMASK_TYPES.CONNECT,
							payload: {
								active: true,
								design: false,
								showAddress: "",
							},
						});
					} else {
						address = accounts[0];
						if (accounts.length > 0) {
							dispatch({
								type: METAMASK_TYPES.CONNECT,
								payload: {
									address: address,
									active: false,
									design: true,
									showAddress:
										address.slice(0, 4) + "..." + address.slice(38, 42),
								},
							});
							localStorage.setItem("address", address);
						} else {
							localStorage.removeItem("address");
							dispatch({
								type: METAMASK_TYPES.CONNECT,
								payload: {
									address: "",
									active: true,
									design: false,
									showAddress: "",
								},
							});
						}
					}
				});

				provider.on("chainChanged", (chainId) => {
					if (
						chainId !== "0x38" ||
						chainId !== 56 ||
						chainid === "0x61" ||
						chainid === 97
					) {
						web3Modal.clearCachedProvider();
						dispatch({
							type: METAMASK_TYPES.CONNECT,
							payload: {
								active: true,
								design: false,
								showAddress: "",
							},
						});
						toast.info("Please switch to Binance Smart Chain!", {
							position: toast.POSITION.TOP_CENTER,
						});
					}
					if (
						chainId === "0x38" ||
						chainId === 56 ||
						chainid === "0x61" ||
						chainid === 97
					) {
						dispatch({
							type: METAMASK_TYPES.CONNECT,
							payload: {
								address: address,
								active: false,
								design: true,
								showAddress:
									address.slice(0, 4) + "..." + address.slice(38, 42),
							},
						});
					}
				});
			}
		} else {
			dispatch({
				type: METAMASK_TYPES.CONNECT,
				payload: {
					active: true,
					design: false,
					showAddress: "",
				},
			});
		}
	} catch (err) {
		if (err && err.response && err.response.data) {
			dispatch({
				type: GlobalTypes.NOTIFY,
				payload: {
					error: err.response.data.msg,
				},
			});
		}
	}
};

export const disconnectWallet = () => async (dispatch) => {
	try {
		dispatch({ type: GlobalTypes.NOTIFY, payload: { loading: true } });
		localStorage.removeItem("modalProvider");
		localStorage.removeItem("WEB3_CONNECT_CACHED_PROVIDER");
		localStorage.removeItem("address");
		dispatch({
			type: METAMASK_TYPES.CONNECT,
			payload: {
				active: true,
				design: false,
			},
		});
		dispatch({ type: GlobalTypes.NOTIFY, payload: { loading: false } });
	} catch (err) {
		if (err && err.response && err.response.data) {
			dispatch({
				type: GlobalTypes.NOTIFY,
				payload: {
					error: err.response.data.msg,
				},
			});
		}
	}
};
// if (!web3) {
	if (Number(localStorage.getItem("modalProvider"))) {
		checkWalletConnection();
	// } else metamaskConnectInit();
}

export { web3 };