import React from "react";
import "./Banner.css";
//banner component.
const Banner = () => {
	return (

		<div>
			<div className="banner ho_me">
				<div className="container_cust">

					<div className="inner_banner ho_me">
					{/* <a href="https://t.me/seedifyfund/610" target="_blank" rel="noopener noreferrer"><div className="blink-text" style={{ fontSize: 25 }}>Rebranding of Seedify is ongoing. Check the new design here</div></a> */}

						<h1>
						Enter the gateway of Blockchain Gaming
						</h1>
						{/* <p> Get the blockchain gaming tokens you love, through holding SFUND
						</p> */}
						<a
							className="gen_btn new_btns join_banner_btn"
							href="https://p50z1ifoy8t.typeform.com/to/iSzThzNs"
							target="_blank" rel="noopener noreferrer">
							Apply for IDO
						</a>
						<a
							className="gen_btn new_btns join_banner_btn"
							href=" https://pancakeswap.finance/swap#/swap?outputCurrency=0x477bc8d23c634c154061869478bce96be6045d12"
							target="_blank" rel="noopener noreferrer">
							Buy on Pancakeswap
						</a>
						<a
							className="gen_btn new_btns join_banner_btn"
							href="https://kucoin.com/trade/SFUND-USDT"
							target="_blank" rel="noopener noreferrer">
							Buy on KuCoin
						</a>
					</div>
				</div>
				<div className="nd_banner">
			   <div className="container_cust">
			        <div className="speedi_grd">
			           <div className="speedi_inner_grd">
					   <div className="inner_sp_grd">
						   <h2>What is Seedify.fund</h2>
						   <p>Fanadise is an exclusive content platform created for internet influencers to monetize.</p>
						   <a href="#">Learn more</a>
						 </div>
			            </div>
						<div className="speedi_inner_grd">
						<div className="inner_sp_grd">
						   <h2>Tier System</h2>
						   <p>Fanadise is an exclusive content platform created for internet influencers to monetize.</p>
						   <a href="#">Learn more</a>
						 </div>
						</div>
						<div className="speedi_inner_grd">
						<div className="inner_sp_grd">
						   <h2>How to get started</h2>
						   <p>Fanadise is an exclusive content platform created for internet influencers to monetize.</p>
						   <a href="#">Learn more</a>
						 </div>
					</div>
			        </div>
		      </div>
		    </div>
			</div>
			
		</div>
	);
};
export default Banner;
