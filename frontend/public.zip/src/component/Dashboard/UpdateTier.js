import React, { useState } from "react";
import Web3 from "web3";
import { SeedifyFundsContractAbi } from "../../abis3";
import { useDispatch } from 'react-redux'
import GlobalTypes from "../../redux/actions/GlobalTypes";
import { useParams } from "react-router-dom";
const web3 = new Web3(Web3.givenProvider);

//update tier component
const UpdateTier = () => {
	const [number1, setNumber1] = useState();
	const [number2, setNumber2] = useState();
	const [number3, setNumber3] = useState();
	var contractAddr = useParams().address.toUpperCase()

	const simpleContract = new web3.eth.Contract(
		SeedifyFundsContractAbi,
		contractAddr,
	);
	const dispatch = useDispatch();
	const handleSet = async () => {

		if (window.ethereum) {
			window.web3 = new Web3(window.ethereum);
			window.ethereum.enable();
		}
		//get account address of metamask. 
		const accounts = await window.web3.eth.getAccounts()
		const account = accounts[0];
		const updateTier = await simpleContract.methods.updateTierValues(number1, number2, number3).send({ from: account });
       if (updateTier.status) {
			dispatch({
				type: GlobalTypes.NOTIFY,
				payload: {
					success: 'Tiers value updated successfully.',
				},
			});
		}
	};

	return (
		<div>
			<div className="right-panel-main">
				<h2>Update Tier Value</h2>
				<div className="rightpanel-form">
					<div className="form-inner">
						<div className="form-group">
							<label>Value of Tier One</label>
							<input
								type="text"
								className="input-form"
								value={number1}
								onChange={(e) => setNumber1(e.target.value)}
								placeholder="Enter value"
							/>
						</div>
					</div>
					<div className="form-inner">
						<div className="form-group">
							<label>Value of Tier Two</label>
							<input
								type="text"
								className="input-form"
								value={number2}
								onChange={(e) => setNumber2(e.target.value)}
								placeholder="Enter value"
							/>
						</div>
					</div>
					<div className="form-inner">
						<div className="form-group">
							<label>Value of Tier Three</label>
							<input
								type="text"
								className="input-form"
								value={number3}
								onChange={(e) => setNumber3(e.target.value)}
								placeholder="Enter value"
							/>
						</div>
					</div>
					<div className="form-group">
						<button onClick={handleSet} type="button" className="btn">
							SUBMIT
						</button>
					</div>
				</div>
			</div>
		</div>
	);
};

export default UpdateTier;
