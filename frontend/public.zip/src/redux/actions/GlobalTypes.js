const TYPES = {
	AUTH: "AUTH",
	NOTIFY: "NOTIFY",
};

export default TYPES;
