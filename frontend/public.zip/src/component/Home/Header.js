import React, { useEffect } from "react";
import { Link } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import "./Header.css";
import logo from "../../images/Logo.png";
import medium from "../../images/medium.svg";
import Modal from "@material-ui/core/Modal";
import Web3 from "web3";
import 'react-toastify/dist/ReactToastify.css'
import { disconnectWallet, connectWallet, checkWalletConnection } from "../../redux/actions/metamaskAction";
import TelegramIcon from '@material-ui/icons/Telegram';


const Header = () => {
	const { auth, metamask } = useSelector((state) => state);

	const dispatch = useDispatch() 
	const provider = Web3.givenProvider;

	//check connection
	    useEffect(() => {
	 	dispatch(checkWalletConnection())
		
	},[dispatch, provider])
	
	//connect wallet
	const connectMetamask = async () => {
		dispatch(connectWallet())
	};
	//disconnect wallet
	const disconnectwallet = () => {
		dispatch(disconnectWallet());
		handleClose();
	};
	const [open, setOpen] = React.useState(false);
	const handleOpen = () => {
		setOpen(true);
	};
	const handleClose = () => {
		setOpen(false);
	};
//   console.log("metamask",metamask)
	const body = (
		<div className="paper">
			<h2 className="paper_h2" id="simple-modal-title">
				Your wallet
			</h2>
			<br />
			<input
				className="paper_input"
				type="text"
				name="amount"
				value={metamask.address}
				readOnly
			/>{" "}
			<br />
			<br />
			<button className="paper_button" onClick={() => disconnectwallet()}>
				Disconnect
			</button>
		</div>
	);
//    console.log("metamsk", metamask )
	return (
		<div>
			<header className="hea_der">
				<div className="container_cust">
					<div className="inner_header">
						<div className="logo">
							<Link to="/">
								<img src={logo} alt="" />
							</Link>
						</div>
						<div className="navi_gation">
							<Link
								className="gen_btn btn_white"
								to={
									auth.token && auth.role
										? "/admin/upcommingpool"
										: "/admin/login"
								}>
								dashboard
							</Link>

							<nav className="navbar navbar-expand-lg navbar-light bg-light">
								<button
									className="navbar-toggler"
									type="button"
									data-toggle="collapse"
									data-target="#navbarSupportedContent"
									aria-controls="navbarSupportedContent"
									aria-expanded="false"
									aria-label="Toggle navigation">
									<span className="navbar-toggler-icon"></span>
								</button>

								<div className="collapse navbar-collapse"
									id="navbarSupportedContent">
									<ul className="navbar-nav white-ul">
                                      <li className="nav-item">
											<a className="nav-link" href="#">Projects</a>
										</li>
										 <li className="nav-item">
											<Link className="nav-link" to="/staking">Staking/Farming</Link>
										</li>
										 <li className="nav-item">
											<a className="nav-link" href="#">Whitelist</a>
										</li>
										 <li className="nav-item">
											<a className="nav-link" href="#">Whitepaper</a>
										</li>
									</ul>
									<div className="right-tophead">
									<ul className="navbar-nav icon-nav">
										<li className="nav-item ">
											<a className="nav-link" href="https://twitter.com/SeedifyFund"
												target="_blank" rel="noopener noreferrer"><span><i className="fa fa-twitter" aria-hidden="true"></i></span> </a>
										</li>
										<li className="nav-item">
											<a className="nav-link" href="https://seedifyfund.medium.com/"
												target="_blank" rel="noopener noreferrer"><span><img src={medium} /> </span></a>
										</li>
										<li className="nav-item">
											<a className="nav-link" href="https://t.me/seedifyfund " target="_blank" rel="noopener noreferrer"> <TelegramIcon /></a>
										</li>	
									</ul>
									
									<div className="nav-item d-mobile">
											{metamask.active ? (
												<button
													className="gen_bttn btn_white connect_btn yellow_btn"
													onClick={() => connectMetamask()}>
													connect wallet
												</button>
											) : (
												""
											)}

											<div>
												{metamask.design ? (
													<div>
														<button
															className="addressh"
															onClick={() => handleOpen()}>
															{metamask.showAddress}
														</button>
													</div>
												) : null}
											</div>
										</div>                                       
									</div>
								</div>
							</nav>
							<div className="nav-item d-tab">
							<ul className="navbar-nav icon-nav">
										<li className="nav-item ">
											<a className="nav-link" href="https://twitter.com/SeedifyFund"
												target="_blank" rel="noopener noreferrer"><span><i className="fa fa-twitter" aria-hidden="true"></i></span> </a>
										</li>
										<li className="nav-item">
											<a className="nav-link" href="https://seedifyfund.medium.com/"
												target="_blank" rel="noopener noreferrer"><span><img src={medium} /></span></a>
										</li>
										<li className="nav-item">
											<a className="nav-link" href="https://t.me/seedifyfund " target="_blank" rel="noopener noreferrer"> <TelegramIcon /></a>
										</li>	
									</ul>
								{metamask.active ? (
									<button
										className="gen_bttn btn_white connect_btn yellow_btn"
										onClick={() => connectMetamask()}>
										connect wallet
									</button>
								) : (
									""
								)}

								<div>
									{metamask.design ? (
										<div>
											<button
												className="addressh"
												onClick={() => handleOpen()}>
												{metamask.showAddress}
											</button>
										</div>
									) : null}
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
			<div>
				<Modal
					open={open}
					onClose={handleClose}
					aria-labelledby="simple-modal-title"
					aria-describedby="simple-modal-description">
					{body}
				</Modal>
			</div>
		</div>
	);
};

export default Header;
