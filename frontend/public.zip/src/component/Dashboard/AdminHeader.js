import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { logout } from "../../redux/actions/authAction";
import GlobalTypes from "../../redux/actions/GlobalTypes";
import { getDataAPI } from "../../utils/API";
import profile from "../../images/profile.png";
import droparrow from "../../images/drop-arrow.png";
import dropdown_up from "../../images/drop-up.png";

//admin header component.
const AdminHeader = () => {
  const [search, setSearch] = useState("");
  const [pools, setPools] = useState([]);
  const dispatch = useDispatch();

  useEffect(() => {
    if (search) {
      getDataAPI(`search?title=${search}`)
        .then((res) => setPools(res.data.pool))
        .catch((err) => {
          dispatch({
            type: GlobalTypes.NOTIFY,
            payload: {
              error: err.response.data.msg,
            },
          });
        });
    }
  }, [search, dispatch]);

  useEffect(() => {
    window.onclick = function (event) {
      if (!event.target.matches(".dropbtn")) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
          var openDropdown = dropdowns[i];
          if (openDropdown.classList.contains("show")) {
            openDropdown.classList.remove("show");
          }
        }
      }
    };
  }, []);

  const drop_toggle = () => {
    document.getElementById("myDropdown").classList.toggle("show");
  };

  return (
    <div>
      <div className="right-top">
        <div className="right-topleft">
          <div className="search-form">
            <input
              type="search"
              name="search"
              value={search}
              onChange={(e) =>
                setSearch(e.target.value)
              }
              placeholder="Search"
              className="search-bar"
              autoComplete="off"
            />
            <button className="btn" type="submit">
              <span>
                {search ? <i className="fa" aria-hidden="true"></i> : <i className="fa fa-search" aria-hidden="true"></i>}
              </span>
            </button>
          </div>
          {search ? (
            <div className="search__drop">
              {pools.map((pool) => (
                <Link key={pool._id} to={`/admin/searchpool/${pool._id}`}>
                  <p className="pool">{pool.title}</p>
                </Link>
              ))}
            </div>
          ) : (
            ""
          )}
        </div>
        <div className="right-topright">
          <div className="profile-bar">
            <img onClick={drop_toggle} src={profile} alt="profile" />
          </div>
          <div className="dropdown">
            <button onClick={drop_toggle} className="dropbtn">
              Seedify Admin{" "}
              <span>
                <img src={droparrow} alt="dropdown" />
              </span>
            </button>
            <div id="myDropdown" className="dropdown-content">
              <img className="dropdown_ups" src={dropdown_up} alt="" />
              <Link to="#" onClick={() => dispatch(logout())}>
                logout
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminHeader;
