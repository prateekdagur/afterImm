import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getico } from "../../redux/actions/icoAction";
import Header from "../Home/Header";
import Banner from "./Banner";
import Pool from "./Pool";
import FeaturedPool from "./FeaturedPool";
import "./Home.css";
import CompletedPool from "./CompletedPool"
import Footer from "../Home/footer";


//home component to see all upcoming and feartured pool.
const Home = () => {
	const { ico } = useSelector((state) => state);
	const dispatch = useDispatch();

	//const z = 1;
	useEffect(() => {
		dispatch(getico());
	}, [dispatch]);

	var comming = 0;
	if (ico.upcpool && ico.upcpool.length) {
		comming = 1;
	}
	var completed = 0;
	if (ico.completed_Pool && ico.completed_Pool.length) {
		completed = 1;
	}

	var featured = 0;
	if (ico.featured && ico.featured.length) {
		featured = 1;
	}
	return (
		<div>
			<Header />
			<Banner />
			{comming ?
				<div className="pools">
					<div className="container_cust">
						<div className="inner_pools">
							<h2>Upcoming Pools</h2>
							<div className="pool_grid home">
								{
									ico.upcpool.map((pool) => (
										<Pool key={pool._id} pool={pool} />
									))

								}
							</div>
						</div>
					</div>
				</div>
				: ""}
			{featured ?
			<div className="pools feat_ured">
				<div className="container_cust">
					<div className="inner_pools">
						<h2>Featured Pools</h2>
						<div className="pool_grid home">

							{ico.featured
								? ico.featured.map((pool) => (
									<FeaturedPool key={pool._id} pool={pool} />
								))
								: ""}
						</div>
					</div>
				</div>
			</div>
			: ""}

			{completed ? 
			<div className="pools feat_ured complets">
				<div className="container_cust">
					<div className="inner_pools">
						<h2>Completed Pools</h2>
						<div className="pool_grid home">
							{ico.completed_Pool
								? ico.completed_Pool.map((pool) => (
									<CompletedPool key={pool._id} pool={pool} />
								))
								: ""}
						</div>
					</div>
				</div>
			</div>			
			: ""}
			<div className="shw-more">
			  <button type="button" class="btn ">Show More</button>
			</div>
		<Footer/>
		</div>
	);
};

export default Home;
