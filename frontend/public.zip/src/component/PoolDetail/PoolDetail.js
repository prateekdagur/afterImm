import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { web3 } from "../../redux/actions/metamaskAction";

import { BrowserRouter as Router } from "react-router-dom";
import { getDataAPI } from "../../utils/API";
import WalletConnectProvider from "@walletconnect/web3-provider";
import Web3Modal from "web3modal";
import Modal from "@material-ui/core/Modal";
import Header from "../Home/Header";

import "./PoolDetail.css";
import PoolInformation from "./PoolInformation";
import AboutProject from "./AboutProject";
import TelegramIcon from '@material-ui/icons/Telegram';
import LanguageIcon from '@material-ui/icons/Language';

//import img1 from "../../images/img1.png";
import Vector1 from "../../images/Vector1.png";
import Vector2 from "../../images/Vector2.png";
import Vector3 from "../../images/Vector3.png";
import Vector4 from "../../images/Vector4.png";
import Vector5 from "../../images/Vector5.png";
import Vector6 from "../../images/Vector6.png";
import bitcoin from "../../images/bitcoin.png";
import txprogress from "../../images/loading.gif";
import { SeedifyFundsContractAbi } from "../abis";
import { toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import { useSelector } from 'react-redux'
import BusdIDOabi from "../busdIDO.json"
import tokenABI from "../tokenABI.json"
import Footer from "../Home/footer";

const providerOptions = {
  walletconnect: {
    package: WalletConnectProvider,
    options: {
      rpc: {
        56: 'https://bsc-dataseed.binance.org/'
        //    0x61: 'https://data-seed-prebsc-1-s1.binance.org:8545/', // BSC Testnet chainId - 97

      },
      chainId: 56,
      network: 'binance',
    }
  }
};
//Web3Modal.
const web3Modal = new Web3Modal({
  cacheProvider: true,
  providerOptions
});
console.log(web3)
toast.configure();
const PoolDetail = () => {
  const { metamask } = useSelector((state) => state);
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // use state hooks to set and get values.
  const [pool_detail, setPool_detail] = useState("");
  const [number1, setNumber1] = useState();
  const [number2, setNumber2] = useState();
  const [amount, setAmount] = useState();
  const [whichtier, setwhichtier] = useState(0);
  const [txloader, settxloader] = useState(false)
  // const [checktierloader, setchecktierloader] = useState(false)
  const [minvalueone, setMinValueOne] = useState()
  const [minvaluetwo, setMinValueTwo] = useState()
  const [minvaluethree, setMinValueThree] = useState()
  const [minvaluefour, setMinValueFour] = useState()
  const [minvaluefive, setMinValueFive] = useState()
  const [minvaluesix, setMinValueSix] = useState()
  const [minvalueseven, setMinValueSeven] = useState()
  const [minvalueeight, setMinValueEight] = useState()
  const [minvaluenine, setMinValueNine] = useState()
  const [tokenAllowance, setTokenAllowance] = useState()
  const [userBalance, setUserBalance] = useState()
  const [totalTokenSupply, setTotalTokenSupply] = useState("")
  const [tierMaxLimit, setTierMaxLimit] = useState('')
  //var checkvalid = 0;
  const id = useParams().id;
  const name = useParams().name;
  var y = 0;
  if (name === "upcomming") {
    y = 1;
  }


  useEffect(() => {
    // Getting res from backend api and setting to the setPool detail.
    getDataAPI(`getPool/${id}`).then((res) => setPool_detail(res.data));
  }, [id]);

  var contractAddr = "";
  if (pool_detail.address) {
    contractAddr = web3.utils.toChecksumAddress(pool_detail.address);
  }

  useEffect(() => {
    const checkTokensApproval = async () => {
      // const web3 = new Web3(provider);
      console.log("metamask address", metamask.address)
      // Get balance of connected address.
      if (web3 && metamask.address) {
        var balance = await web3.eth.getBalance(metamask.address);
        if (pool_detail.crypto_type === "BUSD" && metamask.address) {
          const tokenContractInstance = new web3.eth.Contract(
            tokenABI,
            web3.utils.toChecksumAddress('0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56'),
          );
          const result = web3.utils.fromWei(await tokenContractInstance.methods.allowance(metamask.address, contractAddr).call());
          setTokenAllowance(result);
          const totalSupply = web3.utils.fromWei(await tokenContractInstance.methods.totalSupply().call());
          setTotalTokenSupply(totalSupply)
          balance = await tokenContractInstance.methods.balanceOf(metamask.address).call();
        }
        setUserBalance(balance);

      }
    }
    checkTokensApproval()

  }, [metamask.address, pool_detail, contractAddr])

  useEffect(() => {
    //Consuming smart contract ABI and contract address.
    async function simpleContract() {
      try {
        if (contractAddr) {
          console.log(pool_detail.crypto_type === "BUSD" ? SeedifyFundsContractAbi : BusdIDOabi)

          const SimpleContract = new web3.eth.Contract(
            pool_detail.crypto_type === "BUSD" ? BusdIDOabi : SeedifyFundsContractAbi,
            contractAddr,
          );
          //Getting total bnb from blockchain 
          let totalTokenFxn = pool_detail.crypto_type === "BUSD" ? "totalBUSDReceivedInAllTier" : "totalBnbReceivedInAllTier";
          const result = await SimpleContract.methods[totalTokenFxn]().call();
          //Getting max cap from blockchain 
          const total = await SimpleContract.methods.maxCap().call();
          setNumber2(result / 10 ** 18);
          setNumber1(((result / 10 ** 18) / (total / 10 ** 18)) * 100);
        }
      } catch (err) {
        console.log(err)
      }
    }
    simpleContract()
  }, [contractAddr, pool_detail.crypto_type]);

  useEffect(() => {
    setInterval(async function () {
      //Consuming smart contract ABI and contract address.
      if (contractAddr) {
        const SimpleContract = new web3.eth.Contract(
          pool_detail.crypto_type === "BUSD" ? BusdIDOabi : SeedifyFundsContractAbi,

          contractAddr,
        );
        //Getting total bnb from blockchain 
        let totalTokenFxn = pool_detail.crypto_type === "BUSD" ? "totalBUSDReceivedInAllTier" : "totalBnbReceivedInAllTier";

        const result = await SimpleContract.methods[totalTokenFxn]().call();
        //Getting max cap from blockchain 
        const total = await SimpleContract.methods.maxCap().call();
        setNumber2(result / 10 ** 18);
        setNumber1(((result / 10 ** 18) / (total / 10 ** 18)) * 100);
      }
    }, 20000)

  }, [contractAddr, pool_detail.crypto_type]);

  //function for transaction from metamask.
  const transactionMetamask = async () => {
    try {
      handleClose();
      const avalue = amount * 10 ** 18;

      // check for min allocation.
      if (amount >= minvalueone && whichtier === 1) {
        if (amount > tierMaxLimit) {
          return toast.info("You are investing more than your tier-1 limit!", { position: toast.POSITION.TOP_CENTER })
        }
      }

      else if (amount >= minvaluetwo && whichtier === 2) {

        if (amount > tierMaxLimit) {
          return toast.info("You are investing more than your tier-2 limit!", { position: toast.POSITION.TOP_CENTER })

        }
      }

      else if (amount >= minvaluethree && whichtier === 3) {
        if (amount > tierMaxLimit) {
          return toast.info("You are investing more than your tier-3 limit!", { position: toast.POSITION.TOP_CENTER })
        }
      }

      else if (amount >=
        minvaluefour && whichtier === 4) {
        if (amount > tierMaxLimit) {
          return toast.info("You are investing more than your tier-4 limit!", { position: toast.POSITION.TOP_CENTER })
        }
      }

      else if (amount >=
        minvaluefive && whichtier === 5) {
        if (amount > tierMaxLimit) {
          return toast.info("You are investing more than your tier-5 limit!", { position: toast.POSITION.TOP_CENTER })
        }
      }

      else if (amount >=
        minvaluesix && whichtier === 6) {
        if (amount > tierMaxLimit) {
          return toast.info("You are investing more than your tier-6 limit!", { position: toast.POSITION.TOP_CENTER })
        }
      }

      else if (amount >=
        minvalueseven && whichtier === 7) {
        if (amount > tierMaxLimit) {
          return toast.info("You are investing more than your tier-7 limit!", { position: toast.POSITION.TOP_CENTER })
        }
      }

      else if (amount >=
        minvalueeight && whichtier === 8) {
        if (amount > tierMaxLimit) {
          return toast.info("You are investing more than your tier-8 limit!", { position: toast.POSITION.TOP_CENTER })
        }
      }

      else if (amount >=
        minvaluenine && whichtier === 9) {
        if (amount > tierMaxLimit) {
          return toast.info("You are investing more than your tier-9 limit!", { position: toast.POSITION.TOP_CENTER })
        }
      }
      else {
        return toast.info("Amount must be greater than min tier's allocation", { position: toast.POSITION.TOP_CENTER });
      }

      const provider = window.provider;

      const chainid = provider.chainId;
      //check for BSC Mainnet
      if (chainid === '0x38' || chainid === 56 || chainid === "0x61" || chainid === 97) {

        if (userBalance < avalue) {
          return toast.info("Not enough BNB balance", { position: toast.POSITION.TOP_CENTER });
        }
        const address = window.addressselected

        //loader start before getting data.
        settxloader(true);
        if (pool_detail.crypto_type === "BUSD") {
          const SimpleContract = new web3.eth.Contract(
            pool_detail.crypto_type === "BUSD" ? BusdIDOabi : SeedifyFundsContractAbi,
            contractAddr,
          );
          console.log(avalue, metamask.address)
          await SimpleContract.methods.buyTokens(avalue.toString())
            .send({ from: metamask.address })
            .on("transactionHash", (hash) => {

            })
            .on("receipt", (receipt) => {

              onReciept(receipt)
            })
            .on("error", (error) => {
              onError(error);
            });

        } else {
          const txstatus = await web3.eth.sendTransaction({
            to: pool_detail.address,
            from: address,
            value: avalue,
          });
          console.log(txstatus);
          if (txstatus.status) {
            // loader stop after getting data.
            onReciept(txstatus)

          } else {
            onError()
          }
        }
      } else {
        //Clearing cache to get metamask connection pop up.
        await web3Modal.clearCachedProvider();
        toast.info("Please switch to Binance Smart Chain", { position: toast.POSITION.TOP_CENTER });
      }

    }
    catch (err) {
      console.log(err);
      settxloader(false);
      return {
        connectedStatus: false,
        status: toast.error(
          "Transaction reverted, try again.", { position: toast.POSITION.TOP_CENTER }
        ),
      };
    }
  }



  const onReciept = (txstatus) => {
    settxloader(false);
    var hash = `https://bscscan.com/tx/${txstatus.transactionHash}`;
    var label = "View your transaction";
    const CustomToastWithLink = () => (
      <div style={{ textAlign: "center" }}>
        Transaction confirmed! <br />
        <Router>
          <Link target={"_blank"} style={{ color: "#fff", textDecoration: "underline" }} to={{ pathname: hash }}>{label}</Link>
        </Router>
      </div>
    );
    toast.info(CustomToastWithLink, { position: toast.POSITION.TOP_CENTER });
  }
  const onError = () => {
    settxloader(false);
    return toast.error(
      "Transaction Failed!", { position: toast.POSITION.TOP_CENTER }
    )
  }

  //check tier one valiadation for max cap.
  // const checktieronevalidations = async (amount) => {
  //   const simpleContract = new web3.eth.Contract(
  //     pool_detail.crypto_type === "BUSD" ? BusdIDOabi : SeedifyFundsContractAbi,
  //     contractAddr,
  //   );

  //   // First validation
  //   const maxCap = await simpleContract.methods.maxCap().call()
  //   let totalTokenFxn = pool_detail.crypto_type === "BUSD" ? "totalBUSDReceivedInAllTier" : "totalBnbReceivedInAllTier";

  //   const totalBnbReceivedInAllTier = await simpleContract.methods[totalTokenFxn]().call()

  //   if ((parseInt(totalBnbReceivedInAllTier) + amount) > maxCap) {
  //     toast.info("Purchase would exceed max cap!", { position: toast.POSITION.TOP_CENTER });
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Second validation
  //   const tierOneMaxCap = await simpleContract.methods.tierOneMaxCap().call()
  //   let totalTokenTier1 = pool_detail.crypto_type === "BUSD" ? "totalBUSDInTierOne" : "totalBnbInTierOne";

  //   const totalBnbInTierOne = await simpleContract.methods[totalTokenTier1]().call()

  //   if ((parseInt(totalBnbInTierOne) + amount) > tierOneMaxCap) {
  //     toast.info("Purchase would exceed Tier one max cap!", { position: toast.POSITION.TOP_CENTER });
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Third validation
  //   const maxAllocaPerUserTierOne = await simpleContract.methods.maxAllocaPerUserTierOne().call()
  //   const buyInOneTier = await simpleContract.methods.buyInOneTier(metamask.address).call()

  //   if ((parseInt(buyInOneTier) + amount) > maxAllocaPerUserTierOne) {
  //     toast.info("You are investing more than your tier-1 limit!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  // }

  // //check tier two valiadation for max cap.
  // const checktiertwovalidations = async (amount) => {
  //   const simpleContract = new web3.eth.Contract(
  //     pool_detail.crypto_type === "BUSD" ? BusdIDOabi : SeedifyFundsContractAbi,
  //     contractAddr,
  //   );
  //   setwhichtier(2);
  //   // First validation
  //   const maxCap = await simpleContract.methods.maxCap().call()
  //   let totalTokenFxn = pool_detail.crypto_type === "BUSD" ? "totalBUSDReceivedInAllTier" : "totalBnbReceivedInAllTier";

  //   const totalBnbReceivedInAllTier = await simpleContract.methods[totalTokenFxn]().call()

  //   if ((parseInt(totalBnbReceivedInAllTier) + amount) > maxCap) {
  //     toast.info("Purchase would exceed max cap!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Seond validation
  //   const tierTwoMaxCap = await simpleContract.methods.tierTwoMaxCap().call()
  //   let totalTokenInTierTwo = pool_detail.crypto_type === "BUSD" ? "totalBUSDInTierTwo" : "totalBnbInTierTwo";

  //   const totalBnbInTierTwo = await simpleContract.methods[totalTokenInTierTwo]().call()

  //   if ((parseInt(totalBnbInTierTwo) + amount) > tierTwoMaxCap) {
  //     toast.info("Purchase would exceed Tier two max cap!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Third validation
  //   const maxAllocaPerUserTierTwo = await simpleContract.methods.maxAllocaPerUserTierTwo().call()
  //   const buyInTwoTier = await simpleContract.methods.buyInTwoTier(metamask.address).call()

  //   if ((parseInt(buyInTwoTier) + amount) > maxAllocaPerUserTierTwo) {
  //     toast.info("You are investing more than your tier-2 limit!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  // }

  // //check tier three valiadation for max cap.
  // const checktierthreevalidations = async (amount) => {
  //   const simpleContract = new web3.eth.Contract(
  //     pool_detail.crypto_type === "BUSD" ? BusdIDOabi : SeedifyFundsContractAbi,
  //     contractAddr,
  //   );
  //   setwhichtier(3);
  //   // First validation
  //   const maxCap = await simpleContract.methods.maxCap().call()


  //   let totalTokenFxn = pool_detail.crypto_type === "BUSD" ? "totalBUSDReceivedInAllTier" : "totalBnbReceivedInAllTier";

  //   const totalBnbReceivedInAllTier = await simpleContract.methods[totalTokenFxn]().call()
  //   if ((parseInt(totalBnbReceivedInAllTier) + amount) > maxCap) {
  //     toast.info("Purchase would exceed max cap!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Seond validation
  //   const tierThreeMaxCap = await simpleContract.methods.tierThreeMaxCap().call()
  //   let totalTokenInTierThree = pool_detail.crypto_type === "BUSD" ? "totalBUSDInTierThree" : "totalBnbInTierThree";
  //   const totalBnbInTierThree = await simpleContract.methods[totalTokenInTierThree]().call()

  //   if ((parseInt(totalBnbInTierThree) + amount) > tierThreeMaxCap) {
  //     toast.info("Purchase would exceed Tier three max cap!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Third validation
  //   const maxAllocaPerUserTierThree = await simpleContract.methods.maxAllocaPerUserTierThree().call()
  //   const buyInThreeTier = await simpleContract.methods.buyInThreeTier(metamask.address).call()

  //   if ((parseInt(buyInThreeTier) + amount) > maxAllocaPerUserTierThree) {
  //     toast.info("You are investing more than your tier-3 limit!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  // }

  // const checktierfourvalidations = async (amount) => {
  //   const simpleContract = new web3.eth.Contract(
  //     pool_detail.crypto_type === "BUSD" ? BusdIDOabi : SeedifyFundsContractAbi,
  //     contractAddr,
  //   );

  //   setwhichtier(4);
  //   // First validation
  //   const maxCap = await simpleContract.methods.maxCap().call()
  //   let totalTokenFxn = pool_detail.crypto_type === "BUSD" ? "totalBUSDReceivedInAllTier" : "totalBnbReceivedInAllTier";

  //   const totalBnbReceivedInAllTier = await simpleContract.methods[totalTokenFxn]().call()
  //   if ((parseInt(totalBnbReceivedInAllTier) + amount) > maxCap) {
  //     toast.info("Purchase would exceed max cap!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Seond validation
  //   const tierFourMaxCap = await simpleContract.methods.tierFourMaxCap().call()
  //   let totalTokenInTierFour = pool_detail.crypto_type === "BUSD" ? "totalBUSDInTierFour" : "totalBnbInTierFour";

  //   const totalBnbInTierFour = await simpleContract.methods[totalTokenInTierFour]().call()

  //   if ((parseInt(totalBnbInTierFour) + amount) > tierFourMaxCap) {
  //     toast.info("Purchase would exceed Tier four max cap!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Third validation
  //   const maxAllocaPerUserTierFour = await simpleContract.methods.maxAllocaPerUserTierFour().call()
  //   const buyInFourTier = await simpleContract.methods.buyInFourTier(metamask.address).call()

  //   if ((parseInt(buyInFourTier) + amount) > maxAllocaPerUserTierFour) {
  //     toast.info("You are investing more than your tier-4 limit!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  // }

  // const checktierfivevalidations = async (amount) => {
  //   const simpleContract = new web3.eth.Contract(
  //     pool_detail.crypto_type === "BUSD" ? BusdIDOabi : SeedifyFundsContractAbi,
  //     contractAddr,
  //   );

  //   setwhichtier(5);
  //   // First validation
  //   const maxCap = await simpleContract.methods.maxCap().call()
  //   let totalTokenFxn = pool_detail.crypto_type === "BUSD" ? "totalBUSDReceivedInAllTier" : "totalBnbReceivedInAllTier";

  //   const totalBnbReceivedInAllTier = await simpleContract.methods[totalTokenFxn]().call()
  //   if ((parseInt(totalBnbReceivedInAllTier) + amount) > maxCap) {
  //     toast.info("Purchase would exceed max cap!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Seond validation
  //   const tierFiveMaxCap = await simpleContract.methods.tierFiveMaxCap().call()
  //   let totalTokenInTierFive = pool_detail.crypto_type === "BUSD" ? "totalBUSDInTierFive" : "totalBnbInTierFive";

  //   const totalBnbInTierFive = await simpleContract.methods[totalTokenInTierFive]().call()

  //   if ((parseInt(totalBnbInTierFive) + amount) > tierFiveMaxCap) {
  //     toast.info("Purchase would exceed Tier five max cap!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Third validation
  //   const maxAllocaPerUserTierFive = await simpleContract.methods.maxAllocaPerUserTierFive().call()
  //   const buyInFiveTier = await simpleContract.methods.buyInFiveTier(metamask.address).call()

  //   if ((parseInt(buyInFiveTier) + amount) > maxAllocaPerUserTierFive) {
  //     toast.info("You are investing more than your tier-5 limit!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  // }

  // const checktiersixvalidations = async (amount) => {
  //   const simpleContract = new web3.eth.Contract(
  //     pool_detail.crypto_type === "BUSD" ? BusdIDOabi : SeedifyFundsContractAbi,
  //     contractAddr,
  //   );
  //   setwhichtier(6);
  //   // First validation
  //   const maxCap = await simpleContract.methods.maxCap().call()
  //   let totalTokenFxn = pool_detail.crypto_type === "BUSD" ? "totalBUSDReceivedInAllTier" : "totalBnbReceivedInAllTier";

  //   const totalBnbReceivedInAllTier = await simpleContract.methods[totalTokenFxn]().call()
  //   if ((parseInt(totalBnbReceivedInAllTier) + amount) > maxCap) {
  //     toast.info("Purchase would exceed max cap!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Seond validation
  //   const tierSixMaxCap = await simpleContract.methods.tierSixMaxCap().call()
  //   let totalTokenInTierSix = pool_detail.crypto_type === "BUSD" ? "totalBUSDInTierSix" : "totalBnbInTierSix";

  //   const totalBnbInTierSix = await simpleContract.methods[totalTokenInTierSix]().call()

  //   if ((parseInt(totalBnbInTierSix) + amount) > tierSixMaxCap) {
  //     toast.info("Purchase would exceed Tier six max cap!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Third validation
  //   const maxAllocaPerUserTierSix = await simpleContract.methods.maxAllocaPerUserTierSix().call()
  //   const buyInSixTier = await simpleContract.methods.buyInSixTier(metamask.address).call()

  //   if ((parseInt(buyInSixTier) + amount) > maxAllocaPerUserTierSix) {
  //     toast.info("You are investing more than your tier-6 limit!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  // }

  // const checktiersevenvalidations = async (amount) => {
  //   const simpleContract = new web3.eth.Contract(
  //     pool_detail.crypto_type === "BUSD" ? BusdIDOabi : SeedifyFundsContractAbi,
  //     contractAddr,
  //   );
  //   setwhichtier(7);
  //   // First validation
  //   const maxCap = await simpleContract.methods.maxCap().call()
  //   let totalTokenFxn = pool_detail.crypto_type === "BUSD" ? "totalBUSDReceivedInAllTier" : "totalBnbReceivedInAllTier";

  //   const totalBnbReceivedInAllTier = await simpleContract.methods[totalTokenFxn]().call()
  //   if ((parseInt(totalBnbReceivedInAllTier) + amount) > maxCap) {
  //     toast.info("Purchase would exceed max cap!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Seond validation
  //   const tierSevenMaxCap = await simpleContract.methods.tierSevenMaxCap().call()
  //   let totalTokenInTierSeven = pool_detail.crypto_type === "BUSD" ? "totalBUSDInTierSeven" : "totalBnbInTierSeven";

  //   const totalBnbInTierSeven = await simpleContract.methods[totalTokenInTierSeven]().call()

  //   if ((parseInt(totalBnbInTierSeven) + amount) > tierSevenMaxCap) {
  //     toast.info("Purchase would exceed Tier seven max cap!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Third validation
  //   const maxAllocaPerUserTierSeven = await simpleContract.methods.maxAllocaPerUserTierSeven().call()
  //   const buyInSevenTier = await simpleContract.methods.buyInSevenTier(metamask.address).call()

  //   if ((parseInt(buyInSevenTier) + amount) > maxAllocaPerUserTierSeven) {
  //     toast.info("You are investing more than your tier-7 limit!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  // }

  // const checktiereightvalidations = async (amount) => {
  //   const simpleContract = new web3.eth.Contract(
  //     pool_detail.crypto_type === "BUSD" ? BusdIDOabi : SeedifyFundsContractAbi,
  //     contractAddr,
  //   );
  //   setwhichtier(8);
  //   // First validation
  //   const maxCap = await simpleContract.methods.maxCap().call()
  //   let totalTokenFxn = pool_detail.crypto_type === "BUSD" ? "totalBUSDReceivedInAllTier" : "totalBnbReceivedInAllTier";

  //   const totalBnbReceivedInAllTier = await simpleContract.methods[totalTokenFxn]().call()
  //   if ((parseInt(totalBnbReceivedInAllTier) + amount) > maxCap) {
  //     toast.info("Purchase would exceed max cap!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Seond validation
  //   const tierEightMaxCap = await simpleContract.methods.tierEightMaxCap().call()
  //   let totalTokenInTierEight = pool_detail.crypto_type === "BUSD" ? "totalBUSDInTierEight" : "totalBnbInTierEight";

  //   const totalBnbInTierEight = await simpleContract.methods[totalTokenInTierEight]().call()

  //   if ((parseInt(totalBnbInTierEight) + amount) > tierEightMaxCap) {
  //     toast.info("Purchase would exceed Tier eight max cap!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Third validation
  //   const maxAllocaPerUserTierEight = await simpleContract.methods.maxAllocaPerUserTierEight().call()
  //   const buyInEightTier = await simpleContract.methods.buyInEightTier(metamask.address).call()

  //   if ((parseInt(buyInEightTier) + amount) > maxAllocaPerUserTierEight) {
  //     toast.info("You are investing more than your tier-8 limit!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  // }

  // const checktierninevalidations = async (amount) => {
  //   const simpleContract = new web3.eth.Contract(
  //     pool_detail.crypto_type === "BUSD" ? BusdIDOabi : SeedifyFundsContractAbi,
  //     contractAddr,
  //   );
  //   setwhichtier(9);
  //   // First validation
  //   console.log("called1")
  //   const maxCap = await simpleContract.methods.maxCap().call()
  //   console.log("called2")
  //   let totalTokenFxn = pool_detail.crypto_type === "BUSD" ? "totalBUSDReceivedInAllTier" : "totalBnbReceivedInAllTier";

  //   const totalBnbReceivedInAllTier = await simpleContract.methods[totalTokenFxn]().call(); console.log("called3")
  //   if ((parseInt(totalBnbReceivedInAllTier) + amount) > maxCap) {
  //     toast.info("Purchase would exceed max cap!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Seond validation
  //   const tierNineMaxCap = await simpleContract.methods.tierNineMaxCap().call()
  //   let totalTokenInTierNine = pool_detail.crypto_type === "BUSD" ? "totalBUSDInTierNine" : "totalBnbInTierNine";

  //   const totalBnbInTierNine = await simpleContract.methods[totalTokenInTierNine]().call()

  //   if ((parseInt(totalBnbInTierNine) + amount) > tierNineMaxCap) {
  //     toast.info("Purchase would exceed Tier nine max cap!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  //   // Third validation
  //   const maxAllocaPerUserTierNine = await simpleContract.methods.maxAllocaPerUserTierNine().call()
  //   const buyInNineTier = await simpleContract.methods.buyInNineTier(metamask.address).call()

  //   if ((parseInt(buyInNineTier) + amount) > maxAllocaPerUserTierNine) {
  //     toast.info("You are investing more than your tier-9 limit!", { position: toast.POSITION.TOP_CENTER })
  //     checkvalid = 1;
  //     return checkvalid
  //   }
  // }

  //finally getting white list data and setting state accordingly to get confirm amount modal pop up.
  const checktierswhitelist = async (tier_value) => {
    console.log("1", tier_value)
    if (!metamask.address) {

      return toast.info('Your wallet is not connected!', { position: toast.POSITION.TOP_CENTER })
    }
    //Switch cases according to tiers.
    // if (tier_value.tier > 0) {
    switch (tier_value.tier) {
      case 1:
        setwhichtier(1);
        setTierMaxLimit(pool_detail.max_allocation_tierone)
        setAmount(pool_detail.max_allocation_tierone);
        setMinValueOne(pool_detail.min_allocation_tierone)
        setOpen(true)

        break;
      case 2:
        setwhichtier(2);
        setTierMaxLimit(pool_detail.max_allocation_tiertwo)
        setAmount(pool_detail.max_allocation_tiertwo);
        setMinValueTwo(pool_detail.min_allocation_tiertwo)
        setOpen(true)
        break;
      case 3:
        setwhichtier(3);
        setTierMaxLimit(pool_detail.max_allocation_tierthree)
        setAmount(pool_detail.max_allocation_tierthree);
        setMinValueThree(pool_detail.min_allocation_tierthree)
        setOpen(true)
        break;
      case 4:
        setwhichtier(4);
        setTierMaxLimit(pool_detail.max_allocation_tierfour)
        setAmount(pool_detail.max_allocation_tierfour);
        setMinValueFour(pool_detail.min_allocation_tierfour)
        setOpen(true)
        break;
      case 5:
        setwhichtier(5);
        setTierMaxLimit(pool_detail.max_allocation_tierfive)
        setAmount(pool_detail.max_allocation_tierfive);
        setMinValueFive(pool_detail.min_allocation_tierfive)
        setOpen(true)
        break;
      case 6:
        setwhichtier(6);
        setTierMaxLimit(pool_detail.max_allocation_tiersix)
        setAmount(pool_detail.max_allocation_tiersix);
        setMinValueSix(pool_detail.min_allocation_tiersix)
        setOpen(true)
        break;
      case 7:
        setwhichtier(7);
        setTierMaxLimit(pool_detail.max_allocation_tierseven)
        setAmount(pool_detail.max_allocation_tierseven);
        setMinValueSeven(pool_detail.min_allocation_tierseven)
        setOpen(true)
        break;
      case 8:
        setwhichtier(8);
        setTierMaxLimit(pool_detail.max_allocation_tiereight)
        setAmount(pool_detail.max_allocation_tiereight);
        setMinValueEight(pool_detail.min_allocation_tiereight)
        setOpen(true)
        break;
      case 9:
        setwhichtier(9);
        setTierMaxLimit(pool_detail.max_allocation_tiernine)
        setAmount(pool_detail.max_allocation_tiernine);
        setMinValueNine(pool_detail.min_allocation_tiernine)
        setOpen(true)
        break;
      default:
        return toast.info("This wallet is not KYC verified for any of tiers", { position: toast.POSITION.TOP_CENTER })
    }
    // } else {
    // 	return toast.info('Address does not match!', { position: toast.POSITION.TOP_CENTER })
    // }
    
  }

  if (pool_detail.start_date) {
    var closed = 0;
    var closesIn = 0;
    var startIn = 0;
    var filled = 0;
    var date = new Date()
    var now_utc = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(),
      date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());

    var start = pool_detail.start_date
    var end = pool_detail.end_date
    if (number1 > "99.98") {
      startIn = 0;
      closesIn = 0;
      closed = 0;
      filled = 1;
      y = 1;
    }
    else if (end < now_utc) {
      closed = 1;
      y = 1;
    }
    else if (now_utc < start) {
      startIn = 1;
      y = 1;
    }
    else if ((end >= now_utc) && (now_utc >= start)) {
      closesIn = 1;
      y = 0;
    }
    else {
      startIn = 0;
      closesIn = 0;
      y = 1;
    }
  }

  const [open, setOpen] = React.useState(false);
  const handleClose = () => {
    setOpen(false);

  };

  const body = () => {
    if (pool_detail.crypto_type === "BUSD" && +tokenAllowance === 0) {
      return <div>
        <div className="paper">
          <h2 className="paper_h2" id="simple-modal-title">Approve Token</h2>
          {/* <br />
				Enter amount in {pool_detail.crypto_type ==="BUSD"?"BUSD": "BNB"} :{" "}
				<input
					className="paper_input"
					type="number"
					name="amount"
					value={amount}

					onChange={(e) => setAmount(e.target.value)}
				/>{" "} */}

				<br />
				<br />
				<button
					className="paper_button"
					onClick={() => approveTokens()}>
					Approve
				</button>
			</div>
		</div>
		}else{
		return(
		<div>
			<div className="paper">
				<h2 className="paper_h2" id="simple-modal-title">Buy Token</h2>
				<br />
				Enter amount in {pool_detail.crypto_type ==="BUSD"?"BUSD": "BNB"} :{" "}
				<input
					className="paper_input"
					type="number"
					min="0"
					name="amount"
					value={amount}

					onChange={(e) => setAmount(e.target.value)}
				/>{" "}
				<br />
				<br />
				<button
					className="paper_button"
					onClick={() => transactionMetamask()}>
					Confirm
				</button>
			</div>
		</div>
		//<br />
	)};}
	const approveTokens =async()=>{
		const tokenContractInstance = new web3.eth.Contract(
			tokenABI,
      web3.utils.toChecksumAddress('0xe9e7CEA3DedcA5984780Bafc599bD69ADd087D56'),
			);
		// const { web3Data } = this.state;
		console.log(totalTokenSupply)
		settxloader(true);
		await tokenContractInstance.methods
		  .approve(contractAddr, web3.utils.toWei(totalTokenSupply).toString())
		  .send({ from: metamask.address })
		  .on("transactionHash", (hash) => {
			// onTransactionHash(hash);
			console.log(hash);
		  })
		  .on("receipt", (receipt) => {
			settxloader(false);
			setTokenAllowance(1);
		  })
		  .on("error", (error) => {
			onError(error);
		  });
	}

	const checkTierAddress = async () => {
		await getDataAPI(`csv_get/${[id, metamask.address]}`).then((res) => checktierswhitelist(res.data));
	}
	const [startTime, setStartTime] = useState('')
	const [startTimeMobile, setStartTimeMobile] = useState('')

	//setting time counter.
	setInterval(function () {
		var date = new Date();
		var now_utc = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(),
			date.getUTCHours(), date.getUTCMinutes(), date.getUTCSeconds());

		var closes_in_days = '';
		var closes_in_hours = '';
		var closes_in_minutes = '';
		var closes_seconds = '';
		var desktopTimer = '';
		var mobileTimer = '';
		var closes_in_sec = '';
		if (pool_detail.start_date && startIn) {

			var start = pool_detail.start_date
			closes_in_sec = (start - now_utc) / 1000;

			closes_in_days = Math.floor(
				closes_in_sec / (3600 * 24),
			);

			closes_in_sec -= closes_in_days * 86400;

			closes_in_hours = Math.floor(closes_in_sec / 3600) % 24;
			closes_in_sec -= closes_in_hours * 3600;

			closes_in_minutes = Math.floor(closes_in_sec / 60) % 60;
			closes_in_sec -= closes_in_minutes * 60;

			closes_seconds = Math.floor(closes_in_sec % 60);

			desktopTimer = `${closes_in_days} days: ${closes_in_hours} hours: ${closes_in_minutes} minutes: ${closes_seconds} seconds`
			mobileTimer = `${closes_in_days} d: ${closes_in_hours} h: ${closes_in_minutes} m: ${closes_seconds} s`

			if ((closes_in_days === 0) && (closes_in_hours === 0) && (closes_in_minutes === 0) && (closes_seconds === 2)) {
				window.location.reload();
			}
			setStartTime(desktopTimer)
			setStartTimeMobile(mobileTimer)

		}

		if (pool_detail.end_date && closesIn) {
			var end = pool_detail.end_date;
			closes_in_sec = (end - now_utc) / 1000;


			closes_in_days = Math.floor(
				closes_in_sec / (3600 * 24),
			);

			closes_in_sec -= closes_in_days * 86400;

			closes_in_hours = Math.floor(closes_in_sec / 3600) % 24;
			closes_in_sec -= closes_in_hours * 3600;

			closes_in_minutes = Math.floor(closes_in_sec / 60) % 60;
			closes_in_sec -= closes_in_minutes * 60;

			closes_seconds = Math.floor(closes_in_sec % 60);

			desktopTimer = `${closes_in_days} days: ${closes_in_hours} hours: ${closes_in_minutes} minutes: ${closes_seconds} seconds`
			mobileTimer = `${closes_in_days}d: ${closes_in_hours}h: ${closes_in_minutes}m: ${closes_seconds}s`
			if ((closes_in_days === 0) && (closes_in_hours === 0) && (closes_in_minutes === 0) && (closes_seconds === 2)) {
				window.location.reload();
			}
			setStartTime(desktopTimer)
			setStartTimeMobile(mobileTimer)
		}
	}, 1000)

	var allocation = number2 * pool_detail.up_pool_raise;
  var num = Math.ceil(number1 / 2)
  var full = "";
  if(num === 50){
    full = 'fullupload'
  }
	return (
		<div>
			<Header />
			<div
				className="loader"
				style={{
					color: "white",
					top: "50%",
					left: "0",
					right: "0",
					margin: "0 auto",
					zIndex: 50,
				}}>
				{/* {checktierloader && <img src={txprogress} alt="in progress..." className="transaction_progress_loader" />} */}
				{txloader && <img src={txprogress} alt="transaction in progress..." className="transaction_progress_loader" />}
				{txloader && <p>Transaction in progress...</p>}
			</div>
			<div className="pool_detail_banner">
				<div className="container_cust">
					<div className="inner_pool_detail_banner">
						<div className="left_ban">
							<div className="ti_tle">
								<img src={pool_detail.images} alt="" />
								<div className="socia_grd">
									<div>
										<h3>{pool_detail.title}</h3>

										<p>{pool_detail.content}</p>
									</div>
									<div className="socia_l">
                     <ul>
										<li className="nav-item ">
											<a className="nav-link" href="https://twitter.com/SeedifyFund" target="_blank" rel="noopener noreferrer"><span><i className="fa fa-twitter" aria-hidden="true"></i></span> </a>
										</li>
										<li className="nav-item">
											<a className="nav-link" href="https://seedifyfund.medium.com/"
												target="_blank" rel="noopener noreferrer"><span><i className="fa fa-medium" aria-hidden="true"></i></span></a>
										</li>
										<li className="nav-item">
											<a className="nav-link" href="https://t.me/seedifyfund " target="_blank" rel="noopener noreferrer"> <TelegramIcon /></a>
										</li>
										<li className="nav-item">
											<a className="nav-link" href="https://t.me/seedifyfund " target="_blank" rel="noopener noreferrer"> <LanguageIcon /></a>
										</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div className="right_ban">
						<div className="detail_card_outer">
							<div className="detail_card">
								<div className="tit_row">
									<div className="tit_le2">
										<img src={bitcoin} alt="" />
										<h3><div className="pooldetail-title">
											Binance {pool_detail.crypto_type ==="BUSD"?"USD": ""} Coin{" "}</div>
											<span>
												{" "}
												1 {pool_detail.crypto_type ==="BUSD"?"BUSD": "BNB"} = {pool_detail.up_pool_raise} {pool_detail.symbol}{" "}
											</span>
										</h3>
									</div>									
								</div>

								<div className="allocation">
									<div>
										<p>Total Raised</p>
										<div className="timer_desktop">
											<h3 style={{ color: 'white', fontSize: 18 }}>{number2 ? number2.toFixed(4) : "0"} {pool_detail.crypto_type ==="BUSD"?"BUSD": "BNB"}</h3>
										</div>
										<div className="timer_mobile">
											<h3 style={{ color: 'white', fontSize: 14 }}>{number2 ? number2.toFixed(4) : "0"} {pool_detail.crypto_type ==="BUSD"?"BUSD": "BNB"}</h3>
										</div>

									</div>
									<div className="rts">
										{startIn ? <p className="status-p">Start in</p> : ""}
										<div className="timer_desktop">
											{startIn === 1 ? <h3 style={{ color: 'white', fontSize: 18 }} id="poolonpagestart">{startTime}</h3> : ""}
										</div>
										<div className="timer_mobile">
											{startIn === 1 ? <h3 style={{ color: 'white', fontSize: 14 }} id="poolonpagestart">{startTimeMobile}</h3> : ""}
										</div>
										{closesIn ? <p className="status-p">Ends in</p> : ""}
										<div className="timer_desktop">
											{closesIn === 1 ? <h3 style={{ color: 'white', fontSize: 18 }} id="poolonpagestart">{startTimeMobile}</h3> : ""}
										</div>
										<div className="timer_mobile">
											{closesIn === 1 ? <h3 style={{ color: 'white', fontSize: 14 }} id="poolonpagestart">{startTimeMobile}</h3> : ""}
										</div>
                    {closed ? <p className="status-p">Status</p> : ""}
										{closed ? <h3>Closed</h3> : ""}
										{filled ? <h3>Filled</h3> : ""}
									</div>
								</div>
                
								<div className="prog_bar">
								
                  <div className="prog_bar_grd">
										<span className="prog _percent"><p>Progress</p> {number1 ? number1.toFixed(2) : "0"}%</span>
										{
											<span className="parti _nls">
												{allocation ? allocation.toFixed(2) : "0"}/{pool_detail.total_supply} {pool_detail.symbol}
											</span>
										}
									</div>
									{/* <div className="progress">
										<div className="bar" style={{ width: `${number1}%` }}>
											<p className="percent">{number1}</p>
										</div>
									</div> */}
									<div class={`battery ${full}`}>
                    { num ? 
                      [...Array(num)].map(() => (
                        <div className='bar active' data-power='10'></div>
                      )) : ""
                    }

                  </div>
								</div>
                <div className="buy-btnbtc">
                <div className="buy-token">
										{y ? (
											""
										) : (
											<button
												className="btnn_white"
												onClick={() => checkTierAddress()}>
												Buy Tokens
											</button>
										)}
									</div>
                  <div className="prog_bar_grd">
										<span className="parti">
											<p>Limited</p> Participants {pool_detail.participants}
										</span>
									</div>
                  </div>
							</div>
						</div>
						</div>
					</div>
				</div>
			</div>
			<div>
				{/* Modal for transaction amount input. */}
				<Modal
					open={open}
					onClose={handleClose}
					aria-labelledby="simple-modal-title"
					aria-describedby="simple-modal-description">
					{body()}
				</Modal>
			</div>
			<PoolInformation pool_detail={pool_detail} />
			<AboutProject pool_detail={pool_detail} />
       <Footer/>
		</div>
	);
};

export default PoolDetail;
