import React, { useState, useEffect } from "react";
import { getDataAPI } from "../../utils/API";
import { useParams, NavLink, Link } from "react-router-dom";
import { getstoreClaim, getsendClaimToken } from "../../redux/actions/claimTokenAction";
import { useDispatch } from "react-redux";


//for searching pool.
const SearchPool = () => {
	const [pool, setPool] = useState("");
	const dispatch = useDispatch();
	var id = useParams().id;
	useEffect(() => {
		getDataAPI(`getPool/${id}`).then((res) => setPool(res.data));
	}, [id]);
	const clickClaimStore = (addr) => {

		dispatch(getstoreClaim(addr))
	}
	const clickSendToken = (addr) => {

		dispatch(getsendClaimToken(addr))
	}
	const downloadcsv = async (addr) => {
		await getDataAPI(`generate_csv/${addr}`)
		document.getElementById('download-link').click();
	}
	return (
		<div>
			<h2
				style={{
					color: "white",
					fontSize: 32,
					marginTop: 20,
					marginBottom: 20,
				}}>
				{pool.pool_type} pool
			</h2>

			<div className="upcoming-list">
				{pool ? (
					<div className="inner-box">
						<div className="list-boxes">
							<div className="media">
								<div className="client-name">
									<div className="client-img">
										<img
											src={pool.images}
											alt=""
										/>
									</div>
									<div className="client-info">
										<h5>{pool.title}</h5>
										<h6>
											{pool.address.slice(0, 5)}...{pool.address.slice(37, 42)}
										</h6>
									</div>
								</div>
								<Link
									to={`/admin/editico/${pool._id}`}
									className="fa fa-pencil-square-o"></Link>
							</div>
							<div className="radio">Ratio 1 ETH</div>
							<div className="na">
								N/A
								<span> sfund</span>
							</div>
							<div className="border"></div>
							<div className="percentage">
								<span className="total">BNB</span>
								<span className="sfund">0/{pool.total_supply} SFUND</span>
							</div>
						</div>
						<div className="text-center">
							{pool.address ?
								<NavLink
									to={`/admin/updatetier/${pool.address}`}
									className="coming-soon">
									Update Tiers Value
								</NavLink>
								: ""}
							{pool.address ?
								<NavLink
									to={`/admin/adduserinwhitelist/${pool._id}`}
									className="detail">
									Add User in White List
								</NavLink>
								: ""}
							{pool.address ?
								<Link
									to={`/admin/readwhitelist/${pool.address}`}
									className="coming-soon">
									Read White List
								</Link>
								: ""}
							m                              {pool.address ?
								<a href="#prepare-token" onClick={() => clickClaimStore(pool.address)} className="coming-soon">
									Prepare Claim
								</a>
								: ""}
							{pool.address ?
								<a href="#distribute-token" onClick={() => clickSendToken(pool.address)} className="coming-soon">
									Distribute Token
								</a>
								: ""}
							{pool.address ?
								<a
									href="#download-csv"
									onClick={() => downloadcsv(pool.address)}
									className="coming-soon">
									download csv
								</a>
								: ""}
						</div>
					</div>
				) : (
					""
				)}
			</div>
			<div>
				<a href='/exportcsv/out.csv' download='out.csv' id='download-link'> </a>
			</div>
		</div>
	);
};

export default SearchPool;
