
const DeployNewICO = () => {

	return (
		<div>
			<div className="right-panel-main">
				<h2>Deploy New ICO</h2>
				<form>
					<div className="rightpanel-form">
						<div className="form-inner">
							<div className="form-group">
								<label>Need to Set Maxcap</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Value"
									name="set_maxcap"
									
								/>
							</div>
							<div className="form-group">
								<label>The Limit Of One Tier</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Value"
									name="limit_tier_one"
									
								/>
							</div>
							<div className="form-group">
								<label>Sale Start Time</label>
								<input
									type="date"
									className="input-date"
									placeholder="Enter Start Time"
									name="sale_start_time"
									
								/>
							</div>
							<div className="form-group">
								<label>The Limit Of Tier Two</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Value"
									name="limit_tier_two"
								
								/>
							</div>
							<div className="form-group">
								<label>Sale End Time</label>
								<input
									type="date"
									className="input-date"
									placeholder="Enter end time"
									name="sale_end_time"
								
								/>
							</div>
							<div className="form-group">
								<label>The Limit Of Tier Three</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Value"
									name="limit_tier_three"
								
								/>
							</div>
						</div>
						<div className="form-group">
							<button type="submit" className="btn">
								DEOLOY
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	);
};

export default DeployNewICO;
