import React from "react";
import { Link } from "react-router-dom";
import logo from "../../images/Logo.png";
const Footer = () => (
  <div className="footer">
    <div className="container_cust">
      <div className="footer-inner">
        <div className="footer-logo">
          <Link to="/">
            <img src={logo} alt="" />
          </Link>
          <p>Seedify.fund is a Blockchain Gaming focused Incubator and Launchpad. Through staking $SFUND, become eligible to buy game tokens before everyone else, and have an edge in the play to earn era!
          </p>
        </div>
        <div className="footer-right ">
          <div className="footer-lft">
            <ul className="navbar-nav footer-link">
              <li className="nav-item ">
                <a className="nav-link" href="#">Contact Us</a>
              </li>
              <li className="nav-item ">
                <a className="nav-link" href="#">Whitepaper</a>
              </li>
              <li className="nav-item ">
                <a className="nav-link" href="#">Apply as a Project</a>
              </li>
            </ul>
            <div className="footer-social-tab">
              <ul className="navbar-nav ">
                <li className="nav-item ">
                  <a className="nav-link" href="https://twitter.com/SeedifyFund"
                    target="_blank" rel="noopener noreferrer"><span><i className="fa fa-twitter" aria-hidden="true"></i></span> </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="https://seedifyfund.medium.com/"
                    target="_blank" rel="noopener noreferrer"><span><i className="fa fa-medium" aria-hidden="true"></i></span></a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="https://t.me/seedifyfund "
                    target="_blank" rel="noopener noreferrer"> <span><i className="fa fa-telegram" aria-hidden="true"></i></span></a>
                </li>
              </ul>
            </div>
          </div>
          <ul className="navbar-nav footer-link">
            <li className="nav-item ">
              <a className="nav-link" href="#">Privacy Policy</a>
            </li>
            <li className="nav-item ">
              <a className="nav-link" href="#">Terms of Service </a>
            </li>
            <li className="nav-item ">
              <a className="nav-link" href="#">Security Audits</a>
            </li>
            <li className="nav-item footer-tab"><p>&copy; 2021Seddify.fund</p>
            </li>
          </ul>
          <div className="footer-social">
            <ul className="navbar-nav ">
              <li className="nav-item ">
                <a className="nav-link" href="https://twitter.com/SeedifyFund"
                  target="_blank" rel="noopener noreferrer"><span><i className="fa fa-twitter" aria-hidden="true"></i></span> </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="https://seedifyfund.medium.com/"
                  target="_blank" rel="noopener noreferrer"><span><i className="fa fa-medium" aria-hidden="true"></i></span></a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="https://t.me/seedifyfund "
                  target="_blank" rel="noopener noreferrer"> <span><i className="fa fa-telegram" aria-hidden="true"></i></span></a>
              </li>
            </ul>
            <p className="full-p">&copy; 2021Seddify.fund</p>
          </div>
        </div>
        <div className="copyright-mob">
          <p>&copy; 2021Seddify.fund</p>

          <div className="footer-social-copyright">
            <ul className="navbar-nav ">
              <li className="nav-item ">
                <a className="nav-link" href="https://twitter.com/SeedifyFund"
                  target="_blank" rel="noopener noreferrer"><span><i className="fa fa-twitter" aria-hidden="true"></i></span> </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="https://seedifyfund.medium.com/"
                  target="_blank" rel="noopener noreferrer"><span><i className="fa fa-medium" aria-hidden="true"></i></span></a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="https://t.me/seedifyfund "
                  target="_blank" rel="noopener noreferrer"> <span><i className="fa fa-telegram" aria-hidden="true"></i></span></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default Footer;