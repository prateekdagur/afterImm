import React, { useState, useEffect } from "react";
import { useDispatch } from "react-redux";
import { creatICO, getico } from "../../redux/actions/icoAction";
import { checkImage, checkAbi } from "../../utils/ico_valid";
import GlobalTypes from "../../redux/actions/GlobalTypes";
import { useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import { updateico } from "../../redux/actions/icoAction";
import { Editor } from '@tinymce/tinymce-react';
import { useHistory } from "react-router-dom";


//create ico component to write all details from form.
const CreateICO = () => {
	const dispatch = useDispatch();

	const initialState = {
		title: "",
		total_supply: "",
		symbol: "",
		up_pool_raise: "",
		images: "",
		start_date: "",
		end_date: "",
		content: "",
		min_allocation: "",
		max_allocation: "",
		participants: "",
		swap_amount: "",
		min_swap_level: "",
		address: "",
		decimal: "",
		description: "",
		pool_type: "",
		up_pool_access: "",
		twitter_link: "",
		git_link: "",
		telegram_link: "",
		reddit_link: "",
		medium_link: "",
		browser_web_link: "",
		white_paper: "",
		token_address: "",
		abi_name: "",
		network_type: "",
		crypto_type: "",
		token_distribution_date: "",
		max_allocation_tierone: "",
		max_allocation_tiertwo: "",
		max_allocation_tierthree: "",
		max_allocation_tierfour: "",
		max_allocation_tierfive: "",
		max_allocation_tiersix: "",
		max_allocation_tierseven: "",
		max_allocation_tiereight: "",
		max_allocation_tiernine: "",
		min_allocation_tierone: "",
		min_allocation_tiertwo: "",
		min_allocation_tierthree: "",
		min_allocation_tierfour: "",
		min_allocation_tierfive: "",
		min_allocation_tiersix: "",
		min_allocation_tierseven: "",
		min_allocation_tiereight: "",
		min_allocation_tiernine: "",
	};
	const [icoData, setIcoData] = useState(initialState);
	const {
		pool_type,
		start_date,
		end_date,
		images,
		title,
		up_pool_raise,
		content,
		min_allocation,
		max_allocation,
		up_pool_access,
		participants,
		swap_amount,
		min_swap_level,
		symbol,
		decimal,
		address,
		total_supply,
		description,
		token_address,
		abi_name,
		twitter_link,
		git_link,
		telegram_link,
		reddit_link,
		medium_link,
		browser_web_link,
		white_paper,
		network_type,
		crypto_type,
		token_distribution_date,
		max_allocation_tierone,
		max_allocation_tiertwo,
		max_allocation_tierthree,
		max_allocation_tierfour,
		max_allocation_tierfive,
		max_allocation_tiersix,
		max_allocation_tierseven,
		max_allocation_tiereight,
		max_allocation_tiernine,
		min_allocation_tierone,
		min_allocation_tiertwo,
		min_allocation_tierthree,
		min_allocation_tierfour,
		min_allocation_tierfive,
		min_allocation_tiersix,
		min_allocation_tierseven,
		min_allocation_tiereight,
		min_allocation_tiernine,

	} = icoData;
	const [image, setImages] = useState("");
	const [abi, setAbi] = useState("");
	const [text, setText] = useState('')
	const [onEdit, setOnEdit] = useState(false);
	const { ico, icoid } = useSelector((state) => state);
	const param = useParams();
	var id = param.id
	const history = useHistory();

	useEffect(() => {
		dispatch(getico());
	}, [dispatch]);

	useEffect(() => {
		if (id) {
			setOnEdit(true);
			if (ico.pool) {
				ico.pool.forEach((poo) => {
					if (poo._id === id) {
						setIcoData(poo);
						setText(poo.description)
					}
				});
			}
		} else {
			setOnEdit(false);
		}
	}, [id, ico.pool]);
	
	const handleImage = (e) => {
		const file = e.target.files[0];
		const err = checkImage(file);
		if (err)
			return dispatch({
				type: GlobalTypes.NOTIFY,
				payload: { error: err },
			});
		setImages(file);
	};
	const handleabi = (e) => {
		const abifile = e.target.files[0];
		const err = checkAbi(abifile);
		if (err)
			return dispatch({
				type: GlobalTypes.NOTIFY,
				payload: { error: err },
			});
		setAbi(abifile);
	};
	const handleChangeInput = (e) => {
		const { name, value } = e.target;
		setIcoData({ ...icoData, [name]: value });
	};
	const handleSubmit = (e) => {
		e.preventDefault();

		if (onEdit) {
			dispatch(
				updateico(
					icoData,
					id,
					image,
					images,
					abi,
					abi_name,
					text
				),
			);

		} else {
			dispatch(
				creatICO(
					icoData,
					image,
					abi,
					text
				),
			)
		}
	};

	useEffect(() => {
		if (icoid.id) {
			history.push(`/admin/editico/${icoid.id}`);
		}
	}, [icoid.id, history])
	//project description editior
	const [displayModal, setDisplayModal] = useState(false);
	const handleUpdate = (value) => {
		setText(value)
	};
	return (
		<div>
			{
				displayModal && <div className={`Modal ${displayModal ? 'Show' : ''}`}>
					<Editor
						initialValue={description}
						value={text}
						init={{
							plugins: 'print preview searchreplace autolink directionality visualblocks visualchars fullscreen image link media template codesample table charmap hr pagebreak nonbreaking anchor toc insertdatetime advlist lists textcolor wordcount imagetools contextmenu colorpicker textpattern help',
							toolbar: 'formatselect | bold italic strikethrough forecolor backcolor | link | alignleft aligncenter alignright alignjustify  | numlist bullist outdent indent  | removeformat',
							height: 500
						}}
						onEditorChange={handleUpdate}
					/>
				</div>
			}
			<div className="right-panel-main">
				<h2>{onEdit ? "UPDATE ICO" : "CREATE ICO"}</h2>
				<form onSubmit={handleSubmit}>
					<div className="rightpanel-form">
						<div className="form-inner">
							<div className="form-group">
								<label>ICO Name</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Name"
									required
									name="title"
									value={title}
									onChange={handleChangeInput}
								/>
							</div>
							<div className="form-group">
								<label>Max allocation in BNB for Tier-1</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="max_allocation_tierone"
									value={max_allocation_tierone}
									onChange={handleChangeInput}
								/>
							</div>

						</div>
						<div className="form-inner">
							<div className="form-group">
								<label>ICO Symbol</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Symbol"
									required
									name="symbol"
									value={symbol}
									onChange={handleChangeInput}
								/>
							</div>

							<div className="form-group">
								<label>Max allocation in BNB for Tier-2</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="max_allocation_tiertwo"
									value={max_allocation_tiertwo}
									onChange={handleChangeInput}
								/>
							</div>
						</div>
						<div className="form-inner">
							<div className="form-group">
								<label>Token Price in BNB</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Price"
									required
									name="up_pool_raise"
									value={up_pool_raise}
									onChange={handleChangeInput}
								/>
							</div>
							<div className="form-group">
								<label>Max allocation in BNB for Tier-3</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="max_allocation_tierthree"
									value={max_allocation_tierthree}
									onChange={handleChangeInput}
								/>
							</div>
						</div>
						<div className="form-inner">
							<div className="form-group">
								<label>Total Supply</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Total Supply"
									required
									name="total_supply"
									value={total_supply}
									onChange={handleChangeInput}
								/>
							</div>
							<div className="form-group">
								<label>Max allocation in BNB for Tier-4</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="max_allocation_tierfour"
									value={max_allocation_tierfour}
									onChange={handleChangeInput}
								/>
							</div>

						</div>
						<div className="form-inner">
							<div className="form-group">
								<label>Min Allocation</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Min Allocation"
									name="min_allocation"
									value={min_allocation}
									onChange={handleChangeInput}
								/>
							</div>
							<div className="form-group">
								<label>Max allocation in BNB for Tier-5</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="max_allocation_tierfive"
									value={max_allocation_tierfive}
									onChange={handleChangeInput}
								/>
							</div>
						</div>
						<div className="form-inner">
							<div className="form-group">
								<label>Max Allocation</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Max Allocation"
									name="max_allocation"
									value={max_allocation}
									onChange={handleChangeInput}
								/>
							</div>
							<div className="form-group">
								<label>Max allocation in BNB for Tier-6</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="max_allocation_tiersix"
									value={max_allocation_tiersix}
									onChange={handleChangeInput}
								/>
							</div>
						</div>
						<div className="form-inner">
							<div className="form-group">
								<label>Pool Content</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter content"
									required
									name="content"
									value={content}
									onChange={handleChangeInput}
								/>
							</div>
							<div className="form-group">
								<label>Max allocation in BNB for Tier-7</label>
								<input
									type="text"
									className="input-form"

									placeholder="Enter price"
									required
									name="max_allocation_tierseven"
									value={max_allocation_tierseven}
									onChange={handleChangeInput}
								/>
							</div>
						</div>
						<div className="form-inner">
							<div className="form-group">
								<label>Participants</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter No. of Participants"
									required
									name="participants"
									value={participants}
									onChange={handleChangeInput}
								/>
							</div>
							<div className="form-group">
								<label>Max allocation in BNB for Tier-8</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="max_allocation_tiereight"
									value={max_allocation_tiereight}
									onChange={handleChangeInput}
								/>
							</div>
						</div>
						<div className="form-inner">
							<div className="form-group">
								<label>Swap Amount (e.g. 1 BNB = 10000 XYZ)</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Swap Amount"
									required
									name="swap_amount"
									value={swap_amount}
									onChange={handleChangeInput}
								/>
							</div>
							<div className="form-group">
								<label>Max allocation in BNB for Tier-9</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="max_allocation_tiernine"
									value={max_allocation_tiernine}
									onChange={handleChangeInput}
								/>
							</div>
						</div>
						<div className="form-inner">
							<div className="form-group">
								<label>Min Swap Level</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Min Swap Level"
									name="min_swap_level"
									value={min_swap_level}
									onChange={handleChangeInput}
								/>
							</div>
							<div className="form-group">
								<label>Min allocation in BNB for Tier-1</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="min_allocation_tierone"
									value={min_allocation_tierone}
									onChange={handleChangeInput}
								/>
							</div>
						</div>
						<div className="form-inner">
							<div className="form-group">
								<label>Contract Address</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Address"
									name="address"
									value={address}
									onChange={handleChangeInput}
								/>
							</div>
							<div className="form-group">
								<label>Min allocation in BNB for Tier-2</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="min_allocation_tiertwo"
									value={min_allocation_tiertwo}
									onChange={handleChangeInput}
								/>
							</div>
						</div>

						<div className="form-inner">
							<div className="form-group">
								<label>Token Address</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Token Address"
									name="token_address"
									value={token_address}
									onChange={handleChangeInput}
								/>
							</div>
							<div className="form-group">
								<label>Min allocation in BNB for Tier-3</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="min_allocation_tierthree"
									value={min_allocation_tierthree}
									onChange={handleChangeInput}
								/>
							</div>
						</div>

						<div className="form-inner">
							<div className="form-group">
								<label>Decimals</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Decimals"
									required
									name="decimal"
									value={decimal}
									onChange={handleChangeInput}
								/>
							</div>
							<div className="form-group">
								<label>Min allocation in BNB for Tier-4</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="min_allocation_tierfour"
									value={min_allocation_tierfour}
									onChange={handleChangeInput}
								/>
							</div>
						</div>

						<div className="form-inner">
							<div className="form-group">
								<label>Upload Token ABI (abi.json)</label>
								<input
									type="file"
									className="input-form"
									placeholder="Enter Api Name"
									name="abi_name"
									onChange={handleabi}
								/>
							</div>
							<div className="form-group">
								<label>Min allocation in BNB for Tier-5</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="min_allocation_tierfive"
									value={min_allocation_tierfive}
									onChange={handleChangeInput}
								/>
							</div>
						</div>
						<div className="form-inner">
							<div className="form-group">
								<label>Pool Type</label>
								<select
									className="input-select"
									name="pool_type"
									value={pool_type}
									onChange={handleChangeInput}>
									<option
										className="ico___dropdown"
										value=""
										disabled="disabled"
										required>
										Select Pool Type
									</option>
									<option className="ico___dropdown">featured</option>
									<option className="ico___dropdown">upcomming</option>
									<option className="ico___dropdown">completed</option>
								</select>
							</div>
							<div className="form-group">
								<label>Min allocation in BNB for Tier-6</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="min_allocation_tiersix"
									value={min_allocation_tiersix}
									onChange={handleChangeInput}
								/>
							</div>
						</div>
						<div className="form-inner">
							<div className="form-group">
								<label>Project Description</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Description"
									required
									name="description"
									value={text}
									onChange={e => setText(e.target.value)}
									onClick={() => setDisplayModal(!displayModal)}
								/>
							</div>
							<div className="form-group">
								<label>Min allocation in BNB for Tier-7</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="min_allocation_tierseven"
									value={min_allocation_tierseven}
									onChange={handleChangeInput}
								/>
							</div>
						</div>
						<div className="form-inner">
							<div className="form-group">
								<label>Network Type</label>
								<select
									className="input-select"
									name="network_type"
									value={network_type}
									onChange={handleChangeInput}>
									<option
										className="ico___dropdown"
										value=""
										disabled="disabled"
										required>
										Select Network Type
									</option>
									<option className="ico___dropdown">ETHEREUM</option>
									<option className="ico___dropdown">BSC</option>
								</select>
							</div>
							<div className="form-group">
								<label>Min allocation in BNB for Tier-8</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="min_allocation_tiereight"
									value={min_allocation_tiereight}
									onChange={handleChangeInput}
								/>
							</div>
						</div>

						<div className="form-inner">
							<div className="form-group">
								<label>Token Distribution Date</label>
								<input
									type="datetime-local"
									className="input-date"
									name="token_distribution_date"
									placeholder="Enter Start Date"
									value={token_distribution_date}
									onChange={handleChangeInput}
								/>
							</div>
							<div className="form-group">
								<label>Min allocation in BNB for Tier-9</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter price"
									required
									name="min_allocation_tiernine"
									value={min_allocation_tiernine}
									onChange={handleChangeInput}
								/>
							</div>
						</div>
						<div className="form-inner">
							<div className="form-group">
								<label>Start Date</label>
								<input
									type="text"
									className="input-date"
									name="start_date"
									placeholder="Enter Start Date"
									value={start_date}
									onChange={handleChangeInput}
								/>
							</div>
							<div className="form-group">
								<label>Twitter Link</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Description"
									name="twitter_link"
									value={twitter_link}
									onChange={handleChangeInput}
								/>
							</div>
						</div>

						<div className="form-inner">
							<div className="form-group">
								<label>End Date</label>
								<input
									type="text"
									className="input-date"
									placeholder="Enter End Date"
									name="end_date"
									value={end_date}
									onChange={handleChangeInput}
								/>
							</div>
							<div className="form-group">
								<label>Git Link</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Project Goal"
									name="git_link"
									value={git_link}
									onChange={handleChangeInput}
								/>
							</div>
						</div>

						<div className="form-inner">
							<div className="form-group">
								<label>Pool Access Type</label>
								<select
									className="input-select"
									name="up_pool_access"
									value={up_pool_access}
									onChange={handleChangeInput}>
									<option
										className="ico___dropdown"
										value=""
										disabled="disabled"
										required>
										Select Pool Access Type
									</option>
									<option className="ico___dropdown">Private</option>
									<option className="ico___dropdown">Public</option>
								</select>
							</div>
							<div className="form-group">
								<label>Telegram Link</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Description"
									name="telegram_link"
									value={telegram_link}
									onChange={handleChangeInput}
								/>
							</div>
						</div>
						<div className="form-inner">
							<div className="form-group">
								<label>Crypto Type</label>
								<select
									className="input-select"
									name="crypto_type"
									value={crypto_type}
									onChange={handleChangeInput}>
									<option
										className="ico___dropdown"
										value=""
										disabled="disabled"
										required>
									    Select acceptance currency
									</option>
									<option className="ico___dropdown">BUSD</option>
									<option className="ico___dropdown">BNB</option>
								</select>
							</div>
							<div className="form-group">
								<label>Reddit Link</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Project Goal"
									name="reddit_link"
									value={reddit_link}
									onChange={handleChangeInput}
								/>
							</div>
						</div>
						<div className="form-inner">
						<div className="form-group">
								<label>White Paper</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Project Team"
									name="white_paper"
									value={white_paper}
									onChange={handleChangeInput}
								/>
							</div>
							
							<div className="form-group">
								<label>Browser Web Link</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Project Goal"
									name="browser_web_link"
									value={browser_web_link}
									onChange={handleChangeInput}
								/>
							</div>
						</div>
						<div className="form-inner">
						<div className="form-group">
								<label>Upload Pool logo</label>
								<input
									type="file"
									className="input-form"
									placeholder="Enter Project Team"
									name="images"
									onChange={handleImage}
								/>
							</div>
							<div className="form-group">
								<label>Medium Link</label>
								<input
									type="text"
									className="input-form"
									placeholder="Enter Description"
									name="medium_link"
									value={medium_link}
									onChange={handleChangeInput}
								/>
							</div>
						</div>
                        <div className="form-inner">
						<div className="form-group">
 							{onEdit ? (
 								<img
 									// src={x ? `/img/${x}` : ""}
									 src={images}
 									height="70px"
 									width="70px"
 									alt=""
 								/>
 							) : (
 								""
 							)}
 						</div>
						 </div>


						<div className="form-group">
							<button type="submit" className="btn">
								{onEdit ? "UPDATE" : "CREATE"}
							</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	);
};
export default CreateICO;
